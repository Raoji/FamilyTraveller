import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Menu, X, LogIn, LogOut, LayoutDashboard } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import AuthModal from "./AuthModal";

const NAV_LINKS = [
  { to: "/", label: "Home" },
  { to: "/vehicles", label: "Vehicles" },
  { to: "/how-it-works", label: "How It Works" },
  { to: "/rental-rules", label: "Rental Rules" },
  { to: "/faq", label: "FAQ" },
  { to: "/contact", label: "Contact" },
];

function dashboardPathFor(role) {
  if (role === "admin") return "/admin";
  if (role === "vehicle_owner") return "/owner";
  if (role === "driver") return "/driver";
  return "/dashboard";
}

export default function Header() {
  const auth = useAuth();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [showAuth, setShowAuth] = useState(false);

  return (
    <header className="site-header">
      <div className="header-inner">
        <Link className="logo" to="/">
          <span className="logo-mark">FT</span>
          <span className="logo-word">Family<em>Traveller</em></span>
        </Link>
        <nav className="nav-links">
          {NAV_LINKS.map((l) => (
            <Link key={l.to} className="nav-link" to={l.to}>{l.label}</Link>
          ))}
        </nav>
        <div className="header-actions">
          {auth.user ? (
            <>
              {/* Dashboard link is role-scoped — a customer is never shown
                  Admin here; ProtectedRoute also enforces this server-truth
                  side via RLS regardless of what renders. */}
              <button className="btn btn-ghost admin-link" onClick={() => navigate(dashboardPathFor(auth.role))}>
                <LayoutDashboard size={16} /> Dashboard
              </button>
              <button className="btn btn-ghost admin-link" onClick={() => auth.signOut()}>
                <LogOut size={16} /> Sign Out
              </button>
            </>
          ) : (
            <button className="btn btn-ghost admin-link" onClick={() => setShowAuth(true)}>
              <LogIn size={16} /> Sign In
            </button>
          )}
          <Link className="btn btn-primary" to="/vehicles">Book a Vehicle</Link>
          <button className="menu-toggle" onClick={() => setMenuOpen((v) => !v)} aria-label="Toggle menu">
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>
      {menuOpen && (
        <div className="mobile-menu">
          {NAV_LINKS.map((l) => (
            <Link key={l.to} className="mobile-link" to={l.to} onClick={() => setMenuOpen(false)}>{l.label}</Link>
          ))}
          {auth.user ? (
            <>
              <button className="mobile-link" onClick={() => { navigate(dashboardPathFor(auth.role)); setMenuOpen(false); }}>Dashboard</button>
              <button className="mobile-link" onClick={() => { auth.signOut(); setMenuOpen(false); }}>Sign Out</button>
            </>
          ) : (
            <button className="mobile-link" onClick={() => { setShowAuth(true); setMenuOpen(false); }}>Sign In</button>
          )}
        </div>
      )}
      {showAuth && <AuthModal onClose={() => setShowAuth(false)} />}
    </header>
  );
}
