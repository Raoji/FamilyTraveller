import React from "react";

/** Used whenever a vehicle has no uploaded photos yet (see Section 17). */
export default function VehicleIllustration({ type, tone = "var(--asphalt)", size = 96 }) {
  const twoWheeler = type === "Bike" || type === "Scooter";
  return (
    <svg width="100%" height={size} viewBox="0 0 220 110" style={{ display: "block" }}>
      <ellipse cx="110" cy="96" rx="92" ry="8" fill="rgba(27,26,24,0.10)" />
      {twoWheeler ? (
        <g>
          <circle cx="55" cy="80" r="20" fill="none" stroke={tone} strokeWidth="6" />
          <circle cx="165" cy="80" r="20" fill="none" stroke={tone} strokeWidth="6" />
          <path d="M55 80 L95 50 L130 50 L165 80" fill="none" stroke={tone} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M95 50 L85 30 H105" fill="none" stroke={tone} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
          <circle cx="130" cy="50" r="6" fill={tone} />
          <path d="M40 80 H20" stroke={tone} strokeWidth="6" strokeLinecap="round" />
        </g>
      ) : (
        <g>
          <path
            d="M18 82 C18 66 30 60 44 58 L58 40 C63 33 71 29 80 29 H150 C160 29 168 34 172 42 L182 58 C196 60 206 68 206 82 C206 88 202 92 196 92 H28 C22 92 18 88 18 82 Z"
            fill="none" stroke={tone} strokeWidth="6" strokeLinejoin="round" strokeLinecap="round"
          />
          <path d="M66 58 L76 40 H146 L160 58 Z" fill="none" stroke={tone} strokeWidth="5" strokeLinejoin="round" />
          <line x1="112" y1="40" x2="112" y2="58" stroke={tone} strokeWidth="5" />
          <circle cx="62" cy="90" r="16" fill="#fff" stroke={tone} strokeWidth="6" />
          <circle cx="162" cy="90" r="16" fill="#fff" stroke={tone} strokeWidth="6" />
          <line x1="18" y1="76" x2="40" y2="76" stroke={tone} strokeWidth="5" strokeLinecap="round" />
        </g>
      )}
    </svg>
  );
}
