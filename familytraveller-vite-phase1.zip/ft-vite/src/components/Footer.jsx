import React from "react";
import { Link } from "react-router-dom";
import { Phone, Mail, MapPin } from "lucide-react";

const PHONE = import.meta.env.VITE_CONTACT_PHONE || "Not configured";
const EMAIL = import.meta.env.VITE_CONTACT_EMAIL || "Not configured";
const CITIES = (import.meta.env.VITE_SUPPORT_CITIES || "").split(",").filter(Boolean);

export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-grid">
        <div>
          <div className="logo" style={{ marginBottom: 12 }}>
            <span className="logo-mark">FT</span>
            <span className="logo-word light">Family<em>Traveller</em></span>
          </div>
          <p className="footer-tag">Self-drive vehicles, ready when your journey is. Transparent pricing — no security deposit.</p>
        </div>
        <div>
          <div className="footer-head">Explore</div>
          <Link className="footer-link" to="/vehicles">Vehicles</Link>
          <Link className="footer-link" to="/how-it-works">How It Works</Link>
          <Link className="footer-link" to="/rental-rules">Rental Rules</Link>
          <Link className="footer-link" to="/faq">FAQ</Link>
        </div>
        <div>
          <div className="footer-head">Company</div>
          <Link className="footer-link" to="/contact">Contact Us</Link>
          <Link className="footer-link" to="/terms">Terms &amp; Conditions</Link>
          <Link className="footer-link" to="/privacy">Privacy Policy</Link>
          <Link className="footer-link" to="/cancellation">Cancellation &amp; Refunds</Link>
        </div>
        <div>
          <div className="footer-head">Reach us</div>
          <div className="footer-contact"><Phone size={14} /> {PHONE}</div>
          <div className="footer-contact"><Mail size={14} /> {EMAIL}</div>
          {CITIES.length > 0 && <div className="footer-contact"><MapPin size={14} /> {CITIES.join(" · ")}</div>}
        </div>
      </div>
      <div className="footer-bottom">© {new Date().getFullYear()} FamilyTraveller. All rights reserved.</div>
    </footer>
  );
}
