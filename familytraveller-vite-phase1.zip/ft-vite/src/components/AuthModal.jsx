import React, { useState } from "react";
import { X, Loader2 } from "lucide-react";
import { useAuth } from "../context/AuthContext";

/**
 * Public sign-up only ever offers customer / driver / vehicle_owner —
 * "admin" is never a selectable option here, and even if this list were
 * tampered with client-side, the database trigger (handle_new_user) would
 * still downgrade any other value to "customer". See migration 001.
 */
const PUBLIC_ROLES = [
  { value: "customer", label: "Customer — I want to rent vehicles" },
  { value: "vehicle_owner", label: "Vehicle Owner — I want to list vehicles" },
  { value: "driver", label: "Driver — I want to drive assigned trips" },
];

export default function AuthModal({ onClose, onSuccess, initialMode = "login" }) {
  const { signIn, signUp } = useAuth();
  const [isSignup, setIsSignup] = useState(initialMode === "signup");
  const [form, setForm] = useState({ email: "", password: "", fullName: "", role: "customer" });
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError(""); setNotice(""); setBusy(true);
    try {
      if (isSignup) {
        await signUp(form.email, form.password, form.fullName, form.role);
        setNotice("Check your email to confirm your account, then sign in.");
        setIsSignup(false);
      } else {
        await signIn(form.email, form.password);
        onSuccess?.();
        onClose();
      }
    } catch (err) {
      setError(err.message || "Something went wrong.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}><X size={18} /></button>
        <h3 style={{ marginBottom: 4 }}>{isSignup ? "Create an account" : "Sign in"}</h3>
        <p className="verify-note" style={{ marginBottom: 16 }}>
          {isSignup ? "Choose how you'll use FamilyTraveller." : "Sign in to continue."}
        </p>
        <form onSubmit={submit}>
          {isSignup && (
            <>
              <div className="form-field">
                <label>Full Name</label>
                <input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} required />
              </div>
              <div className="form-field">
                <label>I am a...</label>
                <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
                  {PUBLIC_ROLES.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
                </select>
              </div>
            </>
          )}
          <div className="form-field">
            <label>Email</label>
            <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
          </div>
          <div className="form-field">
            <label>Password</label>
            <input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required minLength={6} />
          </div>
          {error && <div className="err" style={{ marginBottom: 10 }}>{error}</div>}
          {notice && <div className="calc-note" style={{ marginBottom: 10 }}>{notice}</div>}
          <button className="btn btn-primary" style={{ width: "100%" }} disabled={busy}>
            {busy ? <Loader2 size={16} className="spin" /> : (isSignup ? "Sign Up" : "Sign In")}
          </button>
        </form>
        <button className="link-arrow" style={{ marginTop: 14 }} onClick={() => setIsSignup((v) => !v)}>
          {isSignup ? "Already have an account? Sign in" : "New here? Create an account"}
        </button>
      </div>
    </div>
  );
}
