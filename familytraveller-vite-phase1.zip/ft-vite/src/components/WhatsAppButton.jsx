import React from "react";
import { MessageCircle } from "lucide-react";

const WHATSAPP_NUMBER = import.meta.env.VITE_CONTACT_WHATSAPP; // e.g. 911234567890, no + or spaces

export default function WhatsAppButton() {
  if (!WHATSAPP_NUMBER) return null; // don't render a fake/broken contact link
  return (
    <a
      href={`https://wa.me/${WHATSAPP_NUMBER}`}
      target="_blank"
      rel="noreferrer"
      className="wa-fab"
      aria-label="Chat with us on WhatsApp"
      title="Chat on WhatsApp"
    >
      <MessageCircle size={24} strokeWidth={2.2} />
    </a>
  );
}
