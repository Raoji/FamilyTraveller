import React, { useState } from "react";
import { ChevronDown } from "lucide-react";

export default function Accordion({ items }) {
  const [open, setOpen] = useState(0);
  return (
    <div className="accordion">
      {items.map((it, i) => (
        <div className="accordion-item" key={it.title}>
          <button className="accordion-head" onClick={() => setOpen(open === i ? -1 : i)}>
            <span>{it.title}</span>
            <ChevronDown size={16} className={open === i ? "rot" : ""} />
          </button>
          {open === i && <div className="accordion-body">{it.text}</div>}
        </div>
      ))}
    </div>
  );
}
