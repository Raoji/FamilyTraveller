import React from "react";
import { Link } from "react-router-dom";
import { Users, Fuel, Settings2, Star, CircleCheck, CircleAlert, Wrench } from "lucide-react";
import VehicleIllustration from "./VehicleIllustration";
import { money } from "../utils/pricing";

const STATUS_META = {
  available: { label: "Available", color: "var(--moss)", Icon: CircleCheck },
  booked: { label: "Booked", color: "var(--rust)", Icon: CircleAlert },
  maintenance: { label: "Under Maintenance", color: "var(--amber)", Icon: Wrench },
};

export function StatusBadge({ status }) {
  const meta = STATUS_META[status] || STATUS_META.available;
  const Icon = meta.Icon;
  return (
    <span className="status-badge" style={{ color: meta.color, borderColor: meta.color }}>
      <Icon size={13} strokeWidth={2.4} /> {meta.label}
    </span>
  );
}

export default function VehicleCard({ vehicle: v }) {
  const image = v.images?.[0];
  return (
    <div className="v-card">
      <div className="v-card-media">
        {image ? <img src={image} alt={v.name} className="v-card-photo" /> : <VehicleIllustration type={v.type} tone="var(--asphalt)" />}
        <StatusBadge status={v.status} />
      </div>
      <div className="v-card-body">
        <div className="v-card-top">
          <h3>{v.name}</h3>
          {v.rating && <div className="v-rating"><Star size={13} fill="var(--amber)" stroke="var(--amber)" /> {v.rating}</div>}
        </div>
        <div className="v-tags">
          <span>{v.type}</span><span className="dot">·</span>
          <span><Users size={12} /> {v.seats} Seats</span><span className="dot">·</span>
          <span><Fuel size={12} /> {v.fuel}</span><span className="dot">·</span>
          <span><Settings2 size={12} /> {v.transmission}</span>
        </div>
        <div className="v-price-row">
          <div><span className="v-price">{money(v.dailyPrice)}</span><span className="v-price-unit">/day</span></div>
        </div>
        <div className="v-card-actions">
          <Link className="btn btn-outline" to={`/vehicles/${v.id}`}>View Details</Link>
          <Link
            className={"btn btn-primary" + (v.status !== "available" ? " btn-disabled" : "")}
            to={v.status === "available" ? `/vehicles/${v.id}` : "#"}
            onClick={(e) => { if (v.status !== "available") e.preventDefault(); }}
          >
            {v.status === "available" ? "Book Now" : v.status === "booked" ? "Unavailable" : "In Service"}
          </Link>
        </div>
      </div>
    </div>
  );
}
