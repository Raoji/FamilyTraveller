import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { Loader2 } from "lucide-react";

/**
 * Wrap any route element that should require login and/or a specific role.
 * Never rely on this alone for security — it only controls what renders in
 * the browser. The real protection is the RLS policies in migration 001,
 * which is what actually stops a customer from reading another customer's
 * booking or an owner from editing another owner's vehicle, regardless of
 * what this component does or doesn't render.
 */
export default function ProtectedRoute({ children, allow }) {
  const auth = useAuth();

  if (auth.loading) {
    return <div className="section"><Loader2 size={22} className="spin" /></div>;
  }
  if (!auth.user) {
    return <Navigate to="/" replace state={{ requireAuth: true }} />;
  }
  if (allow && !allow.includes(auth.role)) {
    return (
      <div className="section">
        <div className="empty-state">This account doesn't have access to this page.</div>
      </div>
    );
  }
  return children;
}
