import React, { createContext, useContext, useEffect, useState } from "react";
import { supabase } from "../services/supabase";

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, sess) => setSession(sess));
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session?.user) { setProfile(null); return; }
    supabase.from("profiles").select("*").eq("id", session.user.id).single()
      .then(({ data }) => setProfile(data || null));
  }, [session?.user?.id]);

  /**
   * `role` is restricted to customer | driver | vehicle_owner by
   * handle_new_user() in the database trigger — even if a client sent
   * role: "admin" here, the trigger silently downgrades it to "customer".
   * Admin accounts are only ever created by running SQL directly.
   */
  const signUp = async (email, password, fullName, role = "customer") => {
    const safeRole = ["customer", "driver", "vehicle_owner"].includes(role) ? role : "customer";
    const { error } = await supabase.auth.signUp({
      email, password,
      options: { data: { full_name: fullName, role: safeRole } },
    });
    if (error) throw error;
  };

  const signIn = async (email, password) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
  };

  const signOut = async () => { await supabase.auth.signOut(); };

  const value = {
    session,
    user: session?.user || null,
    profile,
    loading,
    signUp,
    signIn,
    signOut,
    role: profile?.role || null,
    isAdmin: profile?.role === "admin",
    isOwner: profile?.role === "vehicle_owner",
    isDriver: profile?.role === "driver",
    isCustomer: profile?.role === "customer",
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
