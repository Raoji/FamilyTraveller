export function validateBookingForm(form, days) {
  const errors = {};
  if (!form.fullName?.trim()) errors.fullName = "Required";
  if (!/^[0-9]{10}$/.test(form.mobile?.trim() || "")) errors.mobile = "Enter a 10-digit mobile number";
  if (!/^\S+@\S+\.\S+$/.test(form.email?.trim() || "")) errors.email = "Enter a valid email";
  if (!form.pickupDate) errors.pickupDate = "Required";
  if (!form.returnDate || days < 1) errors.returnDate = "Return date must be after pickup date";
  if (!form.licence?.trim()) errors.licence = "Required";
  if (!form.idNumber?.trim()) errors.idNumber = "Required";
  return errors;
}

export function validateVehicleForm(form) {
  const errors = {};
  if (!form.name?.trim()) errors.name = "Required";
  if (!form.type) errors.type = "Required";
  if (!form.dailyPrice || Number(form.dailyPrice) <= 0) errors.dailyPrice = "Enter a valid daily price";
  if (!form.city?.trim()) errors.city = "Required";
  return errors;
}

export const isEmpty = (obj) => Object.keys(obj).length === 0;
