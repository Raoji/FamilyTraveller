export const RULES = [
  { title: "Minimum driver age", text: "Drivers must be 21 years or older with at least 1 year of driving experience. Bikes require riders to be 18+." },
  { title: "Valid driving licence", text: "An original, valid driving licence (not a learner's licence) is mandatory at pickup." },
  { title: "Government ID", text: "One government-issued photo ID (Aadhaar, Passport, or Voter ID) is required for verification." },
  { title: "Fuel policy", text: "Vehicles are provided with a full tank and must be returned with a full tank, or the fuel difference plus a refuelling fee will be charged." },
  { title: "Kilometre limit", text: "250 km per day is included. Extra distance is billed at ₹8/km for cars and ₹3/km for two-wheelers." },
  { title: "Late return policy", text: "A grace period of 30 minutes is allowed. Beyond that, late returns are charged at ₹200/hour for cars and ₹80/hour for two-wheelers." },
  { title: "Damage policy", text: "Any damage beyond normal wear and tear will be assessed after vehicle return. Applicable damage charges, if any, will be communicated with an itemised report." },
  { title: "Traffic violations", text: "The customer is responsible for all traffic fines, tolls, and challans incurred during the rental period." },
  { title: "Accident procedure", text: "In case of an accident, contact FamilyTraveller support immediately and file a police report before moving the vehicle, where safe to do so." },
  { title: "Cancellation policy", text: "Full refund if cancelled 48+ hours before pickup, 50% refund between 24-48 hours, and no refund inside 24 hours of pickup." },
];

export const FAQS = [
  { q: "Do you provide a driver?", a: "No. FamilyTraveller vehicles are provided as self-drive rentals only — you're behind the wheel for the whole trip." },
  { q: "Is a security deposit required?", a: "No. FamilyTraveller does not charge a security deposit for bookings. Applicable rental charges, taxes, late-return charges, fuel differences, traffic fines, or damage charges are handled according to the rental agreement." },
  { q: "What documents do I need?", a: "A valid driving licence and one government-issued photo ID. We may also ask for a quick selfie for identity verification." },
  { q: "Can I extend my rental?", a: "Yes, extensions are subject to vehicle availability. Request an extension from your dashboard before your return time." },
  { q: "What if I return the vehicle late?", a: "A short grace period is built in. Beyond that, late-return charges apply per hour — see our Rental Rules for exact rates." },
];

export const VEHICLE_TYPES = ["Hatchback", "Sedan", "SUV", "MUV", "Bike", "Scooter"];
