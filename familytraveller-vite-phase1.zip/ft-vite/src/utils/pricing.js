/**
 * Central pricing engine — the ONLY place rental price is computed.
 * No deposit, anywhere. FamilyTraveller does not charge a security deposit.
 */
export function computePricing(vehicle, days, couponCode) {
  if (!vehicle || !days || days < 1) return null;

  const rentalCost = vehicle.dailyPrice * days;

  let discount = 0;
  let discountLabel = "";
  if (days >= 7) {
    discount = Math.round(rentalCost * 0.14);
    discountLabel = "Weekly discount (14%)";
  } else if (days >= 3) {
    discount = Math.round(rentalCost * 0.05);
    discountLabel = "Multi-day discount (5%)";
  }

  const afterDiscount = rentalCost - discount;

  let couponDiscount = 0;
  if (couponCode?.trim().toUpperCase() === "FIRST10") {
    couponDiscount = Math.round(afterDiscount * 0.1);
  }

  const taxable = afterDiscount - couponDiscount;
  const taxes = Math.round(taxable * 0.05);
  const additionalCharges = 0;
  const total = taxable + taxes + additionalCharges;

  return {
    rentalCost,
    discount,
    discountLabel,
    couponDiscount,
    taxable,
    taxes,
    additionalCharges,
    total,
    days,
  };
}

export const money = (n) => "₹" + Math.round(n).toLocaleString("en-IN");

export function daysBetween(start, end) {
  if (!start || !end) return 0;
  const diff = Math.round((new Date(end) - new Date(start)) / (1000 * 60 * 60 * 24));
  return diff > 0 ? diff : 0;
}
