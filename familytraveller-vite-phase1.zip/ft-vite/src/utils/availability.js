import { supabase } from "../services/supabase";

/**
 * Frontend-only convenience check — tells the UI whether a date range
 * LOOKS free, so we can disable "Proceed to Booking" early and show a
 * friendly message. This is NOT the source of truth: the database's
 * `no_overlapping_blocks` exclusion constraint (see migration 001) is
 * what actually prevents a double-booking, because two requests could
 * race this check at the same instant. Never rely on this function
 * alone to guarantee availability.
 */
export async function isRangeLikelyAvailable(vehicleId, pickupAt, returnAt) {
  const { data, error } = await supabase
    .from("vehicle_blocks")
    .select("id")
    .eq("vehicle_id", vehicleId)
    .lt("start_at", returnAt)
    .gt("end_at", pickupAt)
    .limit(1);

  if (error) {
    // Fail open on the client — the DB constraint still protects us
    // for real at booking time, so a failed pre-check shouldn't block
    // someone from attempting to book.
    console.warn("Availability pre-check failed:", error.message);
    return true;
  }
  return data.length === 0;
}
