import { supabase } from "./supabase";

function mapVehicleRow(v) {
  return {
    id: v.id,
    name: v.name,
    brand: v.brand,
    model: v.model,
    year: v.year,
    type: v.type,
    seats: v.seats,
    fuel: v.fuel,
    transmission: v.transmission,
    mileage: v.mileage,
    ac: v.ac,
    luggage: v.luggage,
    description: v.description,
    dailyPrice: Number(v.daily_price),
    status: v.status,
    verificationStatus: v.verification_status,
    city: v.city,
    ownerId: v.owner_id,
    images: (v.vehicle_images || [])
      .sort((a, b) => (a.is_main ? -1 : 1) - (b.is_main ? -1 : 1) || a.sort_order - b.sort_order)
      .map((img) => supabase.storage.from("vehicle-images").getPublicUrl(img.storage_path).data.publicUrl),
  };
}

/** Public listing — RLS only returns verified vehicles to non-owners. */
export async function fetchVehicles(filters = {}) {
  let query = supabase.from("vehicles").select("*, vehicle_images(storage_path, is_main, sort_order)");

  if (filters.city) query = query.eq("city", filters.city);
  if (filters.type) query = query.eq("type", filters.type);
  if (filters.maxPrice) query = query.lte("daily_price", filters.maxPrice);
  if (filters.availableOnly) query = query.eq("status", "available");

  const { data, error } = await query.order("daily_price", { ascending: true });
  if (error) throw error;
  return data.map(mapVehicleRow);
}

export async function fetchVehicleById(id) {
  const { data, error } = await supabase
    .from("vehicles")
    .select("*, vehicle_images(storage_path, is_main, sort_order)")
    .eq("id", id)
    .single();
  if (error) throw error;
  return mapVehicleRow(data);
}

/** Owner: vehicles they own, including pending/rejected ones RLS hides from the public. */
export async function fetchOwnerVehicles(ownerId) {
  const { data, error } = await supabase
    .from("vehicles")
    .select("*, vehicle_images(storage_path, is_main, sort_order)")
    .eq("owner_id", ownerId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data.map(mapVehicleRow);
}

export async function createVehicle(ownerId, form) {
  const { data, error } = await supabase
    .from("vehicles")
    .insert({
      name: form.name, brand: form.brand, model: form.model, year: form.year,
      type: form.type, seats: form.seats, fuel: form.fuel, transmission: form.transmission,
      mileage: form.mileage, ac: form.ac ?? true, luggage: form.luggage, description: form.description,
      daily_price: form.dailyPrice, city: form.city, owner_id: ownerId,
      status: "available", verification_status: "pending",
    })
    .select()
    .single();
  if (error) throw error;
  return mapVehicleRow(data);
}

export async function updateVehicle(id, updates) {
  const dbUpdates = {};
  const map = {
    name: "name", brand: "brand", model: "model", year: "year", type: "type",
    seats: "seats", fuel: "fuel", transmission: "transmission", mileage: "mileage",
    ac: "ac", luggage: "luggage", description: "description",
    dailyPrice: "daily_price", status: "status", city: "city",
    verificationStatus: "verification_status",
  };
  for (const [key, col] of Object.entries(map)) {
    if (key in updates) dbUpdates[col] = updates[key];
  }
  const { data, error } = await supabase.from("vehicles").update(dbUpdates).eq("id", id).select().single();
  if (error) throw error;
  return mapVehicleRow(data);
}

export async function deleteVehicle(id) {
  const { error } = await supabase.from("vehicles").delete().eq("id", id);
  if (error) throw error;
}

/** Admin: every vehicle regardless of verification/ownership. */
export async function fetchAllVehiclesAdmin() {
  const { data, error } = await supabase
    .from("vehicles")
    .select("*, vehicle_images(storage_path, is_main, sort_order)")
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data.map(mapVehicleRow);
}
