import { createClient } from "@supabase/supabase-js";

export const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

/**
 * Only two operations in this app need a real server instead of a direct
 * Supabase call: creating a Razorpay order (needs the secret key) and
 * receiving Razorpay's webhook (needs the webhook secret + service role).
 * Both live under /api and deploy as serverless functions alongside this
 * Vite build (see /api/README.md). Everything else — vehicles, bookings,
 * documents, admin actions — goes straight to Supabase from the browser
 * and is protected by the RLS policies in the migration, not by a
 * middle-tier API.
 */
export async function apiFetch(path, { method = "GET", body } = {}) {
  const { data: sessionData } = await supabase.auth.getSession();
  const token = sessionData.session?.access_token;

  const res = await fetch(path, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

export function loadRazorpayScript() {
  return new Promise((resolve, reject) => {
    if (window.Razorpay) return resolve(true);
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.onload = () => resolve(true);
    script.onerror = () => reject(new Error("Failed to load Razorpay checkout"));
    document.body.appendChild(script);
  });
}
