import { supabase } from "./supabase";
import { computePricing } from "../utils/pricing";

function mapBookingRow(b) {
  return {
    id: b.id,
    code: b.booking_code,
    vehicleId: b.vehicle_id,
    customerId: b.customer_id,
    ownerId: b.owner_id,
    pickupLocation: b.pickup_location,
    returnLocation: b.return_location,
    pickupAt: b.pickup_at,
    returnAt: b.return_at,
    rentalDays: b.rental_days,
    rentalAmount: Number(b.rental_amount),
    discountAmount: Number(b.discount_amount),
    couponCode: b.coupon_code,
    couponDiscount: Number(b.coupon_discount),
    taxAmount: Number(b.tax_amount),
    additionalCharges: Number(b.additional_charges),
    totalAmount: Number(b.total_amount),
    paymentStatus: b.payment_status,
    bookingStatus: b.booking_status,
    createdAt: b.created_at,
    vehicle: b.vehicles || null,
    customerName: b.customer?.full_name || null,
    customerMobile: b.customer?.mobile || null,
  };
}

/**
 * Creates a booking via the create_booking() RPC (see migration 001).
 * That function is SECURITY DEFINER and inserts the booking + its
 * vehicle_blocks row in one transaction, so a double-booking attempt
 * fails atomically instead of racing a check-then-insert from here.
 * Price is recomputed from the vehicle's real daily_price — never
 * trust a total the UI calculated as the one that gets charged.
 */
export async function createBooking({ vehicle, customerId, pickupLocation, returnLocation, pickupAt, returnAt, days, couponCode, drivingLicenceNo, idProofType, idProofNumber, notes }) {
  const pricing = computePricing(vehicle, days, couponCode);
  if (!pricing) throw new Error("Could not calculate pricing for these dates.");

  const bookingCode = "FT" + Math.floor(100000 + Math.random() * 900000);

  const { data, error } = await supabase.rpc("create_booking", {
    p_customer_id: customerId,
    p_vehicle_id: vehicle.id,
    p_owner_id: vehicle.ownerId || null,
    p_booking_code: bookingCode,
    p_pickup_location: pickupLocation,
    p_return_location: returnLocation || pickupLocation,
    p_pickup_at: pickupAt,
    p_return_at: returnAt,
    p_rental_days: days,
    p_rental_amount: pricing.rentalCost,
    p_discount_amount: pricing.discount,
    p_coupon_code: pricing.couponDiscount > 0 ? couponCode.toUpperCase() : null,
    p_coupon_discount: pricing.couponDiscount,
    p_tax_amount: pricing.taxes,
    p_total_amount: pricing.total,
    p_driving_licence_no: drivingLicenceNo,
    p_id_proof_type: idProofType || null,
    p_id_proof_number: idProofNumber,
    p_notes: notes || null,
  });

  if (error) {
    if (error.message?.includes("no_overlapping_blocks")) {
      throw new Error("These dates were just booked by someone else. Please pick different dates.");
    }
    throw error;
  }
  return { booking: mapBookingRow(data), pricing };
}

export async function fetchBookingById(id) {
  const { data, error } = await supabase.from("bookings").select("*, vehicles(*)").eq("id", id).single();
  if (error) throw error;
  return mapBookingRow(data);
}

export async function fetchCustomerBookings(customerId) {
  const { data, error } = await supabase
    .from("bookings")
    .select("*, vehicles(*)")
    .eq("customer_id", customerId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data.map(mapBookingRow);
}

export async function fetchOwnerBookings(ownerId) {
  const { data, error } = await supabase
    .from("bookings")
    .select("*, vehicles(*), customer:profiles!bookings_customer_id_fkey(full_name, mobile)")
    .eq("owner_id", ownerId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data.map(mapBookingRow);
}

export async function fetchAllBookingsAdmin() {
  const { data, error } = await supabase
    .from("bookings")
    .select("*, vehicles(name, type), customer:profiles!bookings_customer_id_fkey(full_name, mobile)")
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data.map(mapBookingRow);
}

/**
 * Cancelling releases the availability hold so the dates free up again.
 * Allowed for the booking's customer (self-cancel while eligible) or an
 * owner/admin managing the booking — RLS enforces who may actually update.
 */
export async function cancelBooking(bookingId) {
  const { error: blockErr } = await supabase.from("vehicle_blocks").delete().eq("booking_id", bookingId);
  if (blockErr) throw blockErr;
  const { data, error } = await supabase
    .from("bookings")
    .update({ booking_status: "cancelled", updated_at: new Date().toISOString() })
    .eq("id", bookingId)
    .select()
    .single();
  if (error) throw error;
  return mapBookingRow(data);
}

export async function updateBookingStatus(bookingId, bookingStatus) {
  const { data, error } = await supabase
    .from("bookings")
    .update({ booking_status: bookingStatus, updated_at: new Date().toISOString() })
    .eq("id", bookingId)
    .select()
    .single();
  if (error) throw error;
  return mapBookingRow(data);
}

export async function submitReview({ bookingId, customerId, vehicleId, rating, comment }) {
  const { error } = await supabase.from("reviews").insert({
    booking_id: bookingId, customer_id: customerId, vehicle_id: vehicleId, rating, comment,
  });
  if (error) throw error;
}
