import { supabase } from "./supabase";

/**
 * Documents (licence/ID/selfie) upload straight from the browser into the
 * customer's own folder in the private "customer-documents" bucket. This
 * works without a server-side signing step because the storage RLS policy
 * (see migration 001: documents_upload_own_folder) already only allows an
 * authenticated user to write under a path starting with their own user id.
 * Files are never public — read access is limited to the uploader and admins.
 */
export async function uploadDocument({ customerId, bookingId, docType, file }) {
  const ext = file.name.split(".").pop();
  const path = `${customerId}/${docType}-${Date.now()}.${ext}`;

  const { error: uploadErr } = await supabase.storage.from("customer-documents").upload(path, file);
  if (uploadErr) throw uploadErr;

  const { error: insertErr } = await supabase.from("documents").insert({
    customer_id: customerId,
    booking_id: bookingId || null,
    doc_type: docType,
    storage_path: path,
  });
  if (insertErr) throw insertErr;

  return path;
}

export async function fetchCustomerDocuments(customerId) {
  const { data, error } = await supabase.from("documents").select("*").eq("customer_id", customerId);
  if (error) throw error;
  return data;
}

/** Admin: signed, time-limited view URL — documents are never public. */
export async function getDocumentViewUrl(storagePath) {
  const { data, error } = await supabase.storage.from("customer-documents").createSignedUrl(storagePath, 300);
  if (error) throw error;
  return data.signedUrl;
}

export async function verifyDocument(documentId, verified) {
  const { error } = await supabase.from("documents").update({ verified }).eq("id", documentId);
  if (error) throw error;
}

/**
 * Vehicle images upload into a public bucket (renters need to see them
 * without signing in), scoped to the owner's own folder so an owner can
 * only add images under their own path — see vehicle_images_owner_write.
 */
export async function uploadVehicleImage({ ownerId, vehicleId, file, isMain = false, sortOrder = 0 }) {
  const ext = file.name.split(".").pop();
  const path = `${ownerId}/${vehicleId}/${Date.now()}.${ext}`;

  const { error: uploadErr } = await supabase.storage.from("vehicle-images").upload(path, file);
  if (uploadErr) throw uploadErr;

  const { error: insertErr } = await supabase.from("vehicle_images").insert({
    vehicle_id: vehicleId,
    storage_path: path,
    is_main: isMain,
    sort_order: sortOrder,
  });
  if (insertErr) throw insertErr;

  return supabase.storage.from("vehicle-images").getPublicUrl(path).data.publicUrl;
}
