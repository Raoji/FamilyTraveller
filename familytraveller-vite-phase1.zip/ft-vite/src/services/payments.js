import { apiFetch, loadRazorpayScript } from "./supabase";

/**
 * Creates a Razorpay order for a booking via the /api/create-order
 * serverless function (needs the Razorpay secret key, which must never
 * reach the browser). Returns just enough to open Checkout.
 */
export async function createRazorpayOrder(bookingId) {
  return apiFetch("/api/create-order", { method: "POST", body: { bookingId } });
}

/**
 * Opens Razorpay Checkout. IMPORTANT: this `handler` callback firing does
 * NOT mean the booking is paid — it only means the browser saw a success
 * response. The booking's payment_status is set to "paid" only by the
 * /api/webhooks/razorpay function after verifying Razorpay's signature
 * server-side. Treat the handler as "checkout finished, go wait for
 * confirmation," not as "payment confirmed."
 */
export async function openRazorpayCheckout({ order, prefill, onSuccess, onDismiss }) {
  await loadRazorpayScript();
  const rzp = new window.Razorpay({
    key: order.keyId,
    order_id: order.orderId,
    amount: order.amount,
    currency: order.currency,
    name: "FamilyTraveller",
    description: `Booking ${order.bookingCode || ""}`,
    prefill,
    theme: { color: "#E8A23A" },
    handler: () => onSuccess?.(),
    modal: { ondismiss: () => onDismiss?.() },
  });
  rzp.open();
}
