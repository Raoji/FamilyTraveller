import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import Header from "./components/Header";
import Footer from "./components/Footer";
import WhatsAppButton from "./components/WhatsAppButton";

import Home from "./pages/Home";
import Vehicles from "./pages/Vehicles";
import VehicleDetails from "./pages/VehicleDetails";
import Booking from "./pages/Booking";
import Confirmation from "./pages/Confirmation";
import CustomerDashboard from "./pages/CustomerDashboard";
import OwnerDashboard from "./pages/OwnerDashboard";
import DriverDashboard from "./pages/DriverDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import { HowItWorks, RentalRules, Faq, Contact, Terms, Privacy, Cancellation } from "./pages/StaticPages";

import "./styles/index.css";

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <div className="ft-app">
          <Header />
          <main>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/vehicles" element={<Vehicles />} />
              <Route path="/vehicles/:id" element={<VehicleDetails />} />
              <Route path="/booking/:vehicleId" element={<Booking />} />
              <Route path="/confirmation/:bookingId" element={<Confirmation />} />
              <Route path="/how-it-works" element={<HowItWorks />} />
              <Route path="/rental-rules" element={<RentalRules />} />
              <Route path="/faq" element={<Faq />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/terms" element={<Terms />} />
              <Route path="/privacy" element={<Privacy />} />
              <Route path="/cancellation" element={<Cancellation />} />

              <Route path="/dashboard" element={
                <ProtectedRoute allow={["customer"]}><CustomerDashboard /></ProtectedRoute>
              } />
              <Route path="/owner" element={
                <ProtectedRoute allow={["vehicle_owner"]}><OwnerDashboard /></ProtectedRoute>
              } />
              <Route path="/driver" element={
                <ProtectedRoute allow={["driver"]}><DriverDashboard /></ProtectedRoute>
              } />
              <Route path="/admin" element={
                <ProtectedRoute allow={["admin"]}><AdminDashboard /></ProtectedRoute>
              } />
            </Routes>
          </main>
          <Footer />
          <WhatsAppButton />
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}
