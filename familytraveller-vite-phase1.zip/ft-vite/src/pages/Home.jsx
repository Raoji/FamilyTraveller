import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight, Search, MapPin, CalendarDays, Car, Gauge, ShieldCheck, ChevronRight } from "lucide-react";
import VehicleCard from "../components/VehicleCard";
import { fetchVehicles } from "../services/vehicles";

const LOCATIONS = (import.meta.env.VITE_SUPPORT_CITIES || "Mumbai,Pune,Bengaluru").split(",").filter(Boolean);

const STEPS = [
  { n: "01", title: "Choose Vehicle", text: "Browse verified available vehicles by type, price, and location.", icon: Car },
  { n: "02", title: "Select Dates", text: "Pick your pickup and return dates — pricing updates instantly.", icon: CalendarDays },
  { n: "03", title: "Complete Verification", text: "Upload your licence and ID, then complete payment securely.", icon: ShieldCheck },
  { n: "04", title: "Pick Up & Drive", text: "Collect the vehicle at your chosen location and start your journey.", icon: ArrowRight },
];

export default function Home() {
  const navigate = useNavigate();
  const [vehicles, setVehicles] = useState([]);
  const [search, setSearch] = useState({ location: LOCATIONS[0] || "", start: "", end: "", type: "Any" });

  useEffect(() => {
    fetchVehicles({ availableOnly: true }).then((v) => setVehicles(v.slice(0, 3))).catch(() => {});
  }, []);

  const onSearch = () => {
    const params = new URLSearchParams();
    if (search.location) params.set("city", search.location);
    if (search.type !== "Any") params.set("type", search.type);
    if (search.start) params.set("start", search.start);
    if (search.end) params.set("end", search.end);
    navigate(`/vehicles?${params.toString()}`);
  };

  return (
    <div>
      <section className="hero">
        <div className="hero-inner">
          <span className="eyebrow"><Gauge size={13} /> Self-drive, city to highway</span>
          <h1 className="hero-title">
            Drive Your Way.<br />Rent a Vehicle.<br /><span className="hero-accent">No Driver Required.</span>
          </h1>
          <p className="hero-sub">Reliable self-drive vehicles on flexible daily rental plans. Transparent pricing — no security deposit.</p>
          <div className="hero-cta">
            <button className="btn btn-primary btn-lg" onClick={() => navigate("/vehicles")}>Book a Vehicle <ArrowRight size={16} /></button>
            <button className="btn btn-outline btn-lg" onClick={() => navigate("/vehicles")}>Explore Vehicles</button>
          </div>
        </div>
      </section>

      <div className="search-dock">
        <div className="quick-search">
          <div className="qs-field">
            <label><MapPin size={14} /> Pick-up Location</label>
            <select value={search.location} onChange={(e) => setSearch({ ...search, location: e.target.value })}>
              {LOCATIONS.map((l) => <option key={l} value={l}>{l}</option>)}
            </select>
          </div>
          <div className="qs-field">
            <label><CalendarDays size={14} /> Start Date</label>
            <input type="date" value={search.start} onChange={(e) => setSearch({ ...search, start: e.target.value })} />
          </div>
          <div className="qs-field">
            <label><CalendarDays size={14} /> End Date</label>
            <input type="date" value={search.end} min={search.start} onChange={(e) => setSearch({ ...search, end: e.target.value })} />
          </div>
          <div className="qs-field">
            <label><Car size={14} /> Vehicle Type</label>
            <select value={search.type} onChange={(e) => setSearch({ ...search, type: e.target.value })}>
              <option value="Any">Any Type</option>
              {["Hatchback", "SUV", "MUV", "Bike", "Scooter"].map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <button className="btn btn-primary qs-submit" onClick={onSearch}><Search size={16} /> Search Available Vehicles</button>
        </div>
      </div>

      <section className="section">
        <div className="section-head">
          <div><span className="eyebrow">Featured</span><h2>Ready to roll this week</h2></div>
          <button className="link-arrow" onClick={() => navigate("/vehicles")}>View all vehicles <ChevronRight size={16} /></button>
        </div>
        <div className="vehicle-grid">
          {vehicles.length === 0 && <div className="empty-state">No vehicles available right now — check back soon.</div>}
          {vehicles.map((v) => <VehicleCard key={v.id} vehicle={v} />)}
        </div>
      </section>

      <section className="section how-section">
        <span className="eyebrow">The journey</span>
        <h2>How It Works</h2>
        <div className="how-steps">
          {STEPS.map((s) => (
            <div className="how-step" key={s.n}>
              <div className="how-icon"><s.icon size={20} /></div>
              <div className="how-num">{s.n}</div>
              <div className="how-title">{s.title}</div>
              <div className="how-text">{s.text}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="section cta-band">
        <div>
          <h2>Ready for your next trip?</h2>
          <p>Pick your vehicle, choose your dates, and hit the road today.</p>
        </div>
        <button className="btn btn-primary btn-lg" onClick={() => navigate("/vehicles")}>Explore Vehicles <ArrowRight size={16} /></button>
      </section>
    </div>
  );
}
