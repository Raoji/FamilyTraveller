import React from "react";

/**
 * NOT YET IMPLEMENTED. Phase 2 item (Section 14): assigned trips, pickup
 * location, permitted customer info, trip status updates. FamilyTraveller
 * is primarily self-drive, so this role is secondary — build it after
 * the owner dashboard, not before.
 */
export default function DriverDashboard() {
  return (
    <div className="section">
      <div className="empty-state">
        <p style={{ marginBottom: 8, fontWeight: 600 }}>Driver Dashboard — coming in Phase 2</p>
        <p>FamilyTraveller is primarily a self-drive platform, so this role's dashboard (assigned trips, trip status updates) is lower priority than the customer and owner experiences.</p>
      </div>
    </div>
  );
}
