import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Check, X, Loader2, Download } from "lucide-react";
import { fetchBookingById } from "../services/bookings";
import { money } from "../utils/pricing";

export default function Confirmation() {
  const { bookingId } = useParams();
  const navigate = useNavigate();
  const [booking, setBooking] = useState(null);
  const [status, setStatus] = useState("loading"); // loading | waiting | confirmed | error

  useEffect(() => {
    let cancelled = false;
    let interval;
    const poll = async () => {
      try {
        const data = await fetchBookingById(bookingId);
        if (cancelled) return;
        setBooking(data);
        if (data.paymentStatus === "paid") {
          setStatus("confirmed");
          if (interval) clearInterval(interval);
        } else {
          setStatus("waiting");
        }
      } catch (e) {
        if (!cancelled) setStatus("error");
      }
    };
    poll();
    interval = setInterval(poll, 3000);
    return () => { cancelled = true; if (interval) clearInterval(interval); };
  }, [bookingId]);

  if (status !== "confirmed") {
    return (
      <div className="section confirm-wrap">
        <div className="confirm-card">
          <div className="confirm-check" style={{ background: status === "error" ? "var(--rust)" : "var(--amber)" }}>
            {status === "error" ? <X size={26} strokeWidth={3} /> : <Loader2 size={26} className="spin" />}
          </div>
          <h2>{status === "error" ? "Couldn't load booking" : "Confirming your payment…"}</h2>
          <p className="confirm-sub">
            {status === "error"
              ? "We couldn't find this booking. If you completed payment, check your dashboard shortly."
              : "This usually takes a few seconds while we verify payment with Razorpay."}
          </p>
          <button className="btn btn-outline" onClick={() => navigate("/")}>Back to Home</button>
        </div>
      </div>
    );
  }

  const downloadReceipt = () => {
    const lines = [
      "FAMILYTRAVELLER — BOOKING RECEIPT",
      "=================================",
      `Booking ID: ${booking.code}`,
      `Pickup: ${booking.pickupLocation} on ${new Date(booking.pickupAt).toLocaleString("en-IN")}`,
      `Return: ${new Date(booking.returnAt).toLocaleString("en-IN")}`,
      `Duration: ${booking.rentalDays} day(s)`,
      "",
      `Rental Amount: ${money(booking.rentalAmount)}`,
      `Discount: -${money(booking.discountAmount + booking.couponDiscount)}`,
      `Taxes & Fees: ${money(booking.taxAmount)}`,
      `Final Amount: ${money(booking.totalAmount)}`,
      "",
      `Payment Status: ${booking.paymentStatus}`,
      "",
      "Thank you for booking with FamilyTraveller.",
    ];
    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `${booking.code}-receipt.txt`;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="section confirm-wrap">
      <div className="confirm-card">
        <div className="confirm-check"><Check size={30} strokeWidth={3} /></div>
        <h2>Booking Confirmed 🎉</h2>
        <p className="confirm-sub">A confirmation has been sent to your email and phone.</p>

        <div className="confirm-grid">
          <div><span>Booking ID</span><strong>{booking.code}</strong></div>
          <div><span>Vehicle</span><strong>{booking.vehicle?.name}</strong></div>
          <div><span>Pickup Location</span><strong>{booking.pickupLocation}</strong></div>
          <div><span>Pickup</span><strong>{new Date(booking.pickupAt).toLocaleString("en-IN")}</strong></div>
          <div><span>Return</span><strong>{new Date(booking.returnAt).toLocaleString("en-IN")}</strong></div>
          <div><span>Duration</span><strong>{booking.rentalDays} day{booking.rentalDays !== 1 ? "s" : ""}</strong></div>
          <div><span>Final Amount</span><strong>{money(booking.totalAmount)}</strong></div>
          <div><span>Payment Status</span><strong className="paid">Paid</strong></div>
        </div>

        <div className="confirm-actions">
          <button className="btn btn-primary" onClick={downloadReceipt}><Download size={16} /> Download Booking Receipt</button>
          <button className="btn btn-outline" onClick={() => navigate("/")}>Back to Home</button>
        </div>
      </div>
    </div>
  );
}
