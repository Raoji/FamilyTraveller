import React, { useEffect, useMemo, useState } from "react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell,
} from "recharts";
import { Loader2, IndianRupee, CalendarDays, Clock, TrendingUp, Trash2 } from "lucide-react";
import { fetchAllVehiclesAdmin, updateVehicle, deleteVehicle } from "../services/vehicles";
import { fetchAllBookingsAdmin, updateBookingStatus } from "../services/bookings";
import { money } from "../utils/pricing";

const PIE_COLORS = ["#E8A23A", "#3B7A57", "#C1502E", "#445566", "#8A7F68"];

export default function AdminDashboard() {
  const [tab, setTab] = useState("overview");
  const [vehicles, setVehicles] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = () => {
    setLoading(true);
    Promise.all([fetchAllVehiclesAdmin(), fetchAllBookingsAdmin()])
      .then(([v, b]) => { setVehicles(v); setBookings(b); })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const totalRevenue = useMemo(() => bookings.filter((b) => b.paymentStatus === "paid").reduce((s, b) => s + b.totalAmount, 0), [bookings]);
  const activeRentals = bookings.filter((b) => b.bookingStatus === "active").length;
  const pendingVehicles = vehicles.filter((v) => v.verificationStatus === "pending").length;
  const utilization = vehicles.length ? Math.round((vehicles.filter((v) => v.status !== "available").length / vehicles.length) * 100) : 0;

  const revenueByVehicle = vehicles.map((v) => ({
    name: v.name.split(" ").slice(-1)[0],
    revenue: bookings.filter((b) => b.vehicleId === v.id && b.paymentStatus === "paid").reduce((s, b) => s + b.totalAmount, 0),
  }));

  const bookingsByStatus = ["pending", "confirmed", "active", "completed", "cancelled"].map((s) => ({
    name: s, value: bookings.filter((b) => b.bookingStatus === s).length,
  })).filter((d) => d.value > 0);

  const setVerification = async (id, verification_status) => {
    await updateVehicle(id, { verificationStatus: verification_status });
    load();
  };
  const setStatus = async (id, status) => { await updateVehicle(id, { status }); load(); };
  const removeVehicle = async (id) => { await deleteVehicle(id); load(); };
  const setBookingStatusHandler = async (id, status) => { await updateBookingStatus(id, status); load(); };

  return (
    <div className="section admin">
      <div className="section-head"><div><span className="eyebrow">Operations</span><h2>Admin Dashboard</h2></div></div>

      <div className="admin-tabs">
        {[["overview", "Overview"], ["vehicles", "Vehicles"], ["bookings", "Bookings"]].map(([id, label]) => (
          <button key={id} className={"admin-tab" + (tab === id ? " active" : "")} onClick={() => setTab(id)}>{label}</button>
        ))}
      </div>

      {error && <div className="err" style={{ marginBottom: 14 }}>{error}</div>}
      {loading ? <Loader2 size={20} className="spin" /> : (
        <>
          {tab === "overview" && (
            <>
              <div className="stat-grid">
                <div className="stat-card"><IndianRupee size={18} /><div><span>Total Revenue</span><strong>{money(totalRevenue)}</strong></div></div>
                <div className="stat-card"><CalendarDays size={18} /><div><span>Total Bookings</span><strong>{bookings.length}</strong></div></div>
                <div className="stat-card"><Clock size={18} /><div><span>Active Rentals</span><strong>{activeRentals}</strong></div></div>
                <div className="stat-card"><TrendingUp size={18} /><div><span>Pending Verification</span><strong>{pendingVehicles}</strong></div></div>
              </div>
              <div className="chart-grid">
                <div className="chart-card">
                  <h4>Revenue by Vehicle</h4>
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={revenueByVehicle}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#00000012" />
                      <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip formatter={(v) => money(v)} />
                      <Bar dataKey="revenue" fill="var(--amber)" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="chart-card">
                  <h4>Bookings by Status</h4>
                  <ResponsiveContainer width="100%" height={220}>
                    <PieChart>
                      <Pie data={bookingsByStatus} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={3}>
                        {bookingsByStatus.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </>
          )}

          {tab === "vehicles" && (
            <div className="table-wrap">
              <table className="admin-table">
                <thead><tr><th>Vehicle</th><th>Type</th><th>Price/day</th><th>Status</th><th>Verification</th><th></th></tr></thead>
                <tbody>
                  {vehicles.map((v) => (
                    <tr key={v.id}>
                      <td>{v.name}</td>
                      <td>{v.type}</td>
                      <td>{money(v.dailyPrice)}</td>
                      <td>
                        <select value={v.status} onChange={(e) => setStatus(v.id, e.target.value)}>
                          <option value="available">Available</option>
                          <option value="booked">Booked</option>
                          <option value="maintenance">Under Maintenance</option>
                        </select>
                      </td>
                      <td>
                        <select value={v.verificationStatus} onChange={(e) => setVerification(v.id, e.target.value)}>
                          <option value="pending">Pending</option>
                          <option value="under_review">Under Review</option>
                          <option value="verified">Verified</option>
                          <option value="rejected">Rejected</option>
                        </select>
                      </td>
                      <td><button className="icon-btn" onClick={() => removeVehicle(v.id)}><Trash2 size={15} /></button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {tab === "bookings" && (
            <div className="table-wrap">
              {bookings.length === 0 ? <div className="empty-state">No bookings yet.</div> : (
                <table className="admin-table">
                  <thead><tr><th>Booking</th><th>Customer</th><th>Vehicle</th><th>Dates</th><th>Amount</th><th>Status</th></tr></thead>
                  <tbody>
                    {bookings.map((b) => (
                      <tr key={b.id}>
                        <td>{b.code}</td>
                        <td>{b.customerName || "—"}</td>
                        <td>{b.vehicle?.name || "—"}</td>
                        <td>{new Date(b.pickupAt).toLocaleDateString("en-IN")} → {new Date(b.returnAt).toLocaleDateString("en-IN")}</td>
                        <td>{money(b.totalAmount)}</td>
                        <td>
                          <select value={b.bookingStatus} onChange={(e) => setBookingStatusHandler(b.id, e.target.value)}>
                            <option value="pending">Pending</option>
                            <option value="confirmed">Confirmed</option>
                            <option value="active">Active</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                            <option value="rejected">Rejected</option>
                          </select>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}
