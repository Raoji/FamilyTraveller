import React from "react";
import { Car, CalendarDays, ShieldCheck, ArrowRight, Phone, Mail, MapPin, MessageCircle } from "lucide-react";
import Accordion from "../components/Accordion";
import { RULES, FAQS } from "../utils/constants";

const STEPS = [
  { n: "01", title: "Choose Vehicle", text: "Browse verified available vehicles by type, price, and location.", icon: Car },
  { n: "02", title: "Select Dates", text: "Pick your pickup and return dates — pricing updates instantly.", icon: CalendarDays },
  { n: "03", title: "Complete Verification", text: "Upload your licence and ID, then complete payment securely.", icon: ShieldCheck },
  { n: "04", title: "Pick Up & Drive", text: "Collect the vehicle at your chosen location and start your journey.", icon: ArrowRight },
];

export function HowItWorks() {
  return (
    <div className="section how-section">
      <span className="eyebrow">The journey</span>
      <h2>How It Works</h2>
      <div className="how-steps">
        {STEPS.map((s) => (
          <div className="how-step" key={s.n}>
            <div className="how-icon"><s.icon size={20} /></div>
            <div className="how-num">{s.n}</div>
            <div className="how-title">{s.title}</div>
            <div className="how-text">{s.text}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function RentalRules() {
  return (
    <div className="section">
      <span className="eyebrow">Know before you go</span>
      <h2>Rental Rules</h2>
      <p className="page-lead">These rules apply to every FamilyTraveller booking. Transparent pricing — no security deposit.</p>
      <Accordion items={RULES} />
    </div>
  );
}

export function Faq() {
  return (
    <div className="section">
      <span className="eyebrow">Answers</span>
      <h2>Frequently Asked Questions</h2>
      <Accordion items={FAQS.map((f) => ({ title: f.q, text: f.a }))} />
    </div>
  );
}

export function Contact() {
  const phone = import.meta.env.VITE_CONTACT_PHONE || "Not configured";
  const whatsapp = import.meta.env.VITE_CONTACT_WHATSAPP;
  const email = import.meta.env.VITE_CONTACT_EMAIL || "Not configured";
  const cities = (import.meta.env.VITE_SUPPORT_CITIES || "").split(",").filter(Boolean);
  const hours = import.meta.env.VITE_SUPPORT_HOURS || "Not configured";

  return (
    <div className="section">
      <span className="eyebrow">We're here to help</span>
      <h2>Contact Us</h2>
      <div className="contact-grid">
        <div className="contact-card"><Phone size={18} /><div><strong>Call us</strong><span>{phone}</span></div></div>
        <div className="contact-card"><MessageCircle size={18} /><div><strong>WhatsApp</strong><span>{whatsapp ? `+${whatsapp}` : "Not configured"}</span></div></div>
        <div className="contact-card"><Mail size={18} /><div><strong>Email</strong><span>{email}</span></div></div>
        <div className="contact-card"><MapPin size={18} /><div><strong>Cities</strong><span>{cities.join(", ") || "Not configured"}</span></div></div>
      </div>
      <p className="page-lead" style={{ marginTop: 18 }}>Support hours: {hours}</p>
    </div>
  );
}

export function Terms() {
  return <LegalPage title="Terms & Conditions" text="By booking with FamilyTraveller you agree to use the vehicle responsibly, return it on time and in the condition it was received, and comply with all applicable traffic laws. FamilyTraveller does not charge a security deposit; applicable charges (taxes, late fees, fuel difference, damage, fines) are billed per the rental agreement. Full legal terms should be reviewed by counsel before launch." />;
}
export function Privacy() {
  return <LegalPage title="Privacy Policy" text="FamilyTraveller collects only the information needed to verify renters and process bookings. Identity documents are stored privately and are never made public. A complete privacy policy should be reviewed by counsel before launch." />;
}
export function Cancellation() {
  return <LegalPage title="Cancellation & Refund Policy" text="Cancel 48+ hours before pickup for a full refund, 24-48 hours for a 50% refund, or forfeit the rental cost inside 24 hours of pickup. Since no security deposit is collected, there is nothing to refund beyond the rental amount itself." />;
}

function LegalPage({ title, text }) {
  return (
    <div className="section">
      <h2>{title}</h2>
      <p className="page-lead">{text}</p>
    </div>
  );
}
