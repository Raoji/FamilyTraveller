import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { Users, Fuel, Settings2, ArrowRight, BadgeCheck, Loader2 } from "lucide-react";
import VehicleIllustration from "../components/VehicleIllustration";
import { StatusBadge } from "../components/VehicleCard";
import Accordion from "../components/Accordion";
import { fetchVehicleById } from "../services/vehicles";
import { computePricing, daysBetween, money } from "../utils/pricing";
import { RULES } from "../utils/constants";

export default function VehicleDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [vehicle, setVehicle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");

  useEffect(() => {
    fetchVehicleById(id).then(setVehicle).catch((err) => setError(err.message)).finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="section"><Loader2 size={20} className="spin" /></div>;
  if (error) return <div className="section"><p className="err">{error}</p></div>;
  if (!vehicle) return <div className="section"><p>Vehicle not found.</p></div>;

  const days = daysBetween(start, end) || 1;
  const pricing = computePricing(vehicle, days, "");

  const specs = [
    ["Brand", vehicle.brand], ["Model", vehicle.model], ["Year", vehicle.year],
    ["Fuel", vehicle.fuel], ["Transmission", vehicle.transmission], ["Seats", vehicle.seats],
    ["Mileage", vehicle.mileage], ["Air Conditioning", vehicle.ac ? "Yes" : "No"], ["Luggage Capacity", vehicle.luggage],
  ];

  return (
    <div className="section">
      <Link className="link-arrow back" to="/vehicles">← Back to vehicles</Link>
      <div className="details-layout">
        <div>
          <div className="gallery-main">
            {vehicle.images?.length > 0 ? (
              <img src={vehicle.images[0]} alt={vehicle.name} style={{ width: "100%", borderRadius: 12 }} />
            ) : (
              <VehicleIllustration type={vehicle.type} tone="var(--asphalt)" size={220} />
            )}
          </div>

          <div className="details-header">
            <div>
              <h1>{vehicle.name}</h1>
              <div className="v-tags">
                <span>{vehicle.type}</span><span className="dot">·</span>
                <span><Users size={12} /> {vehicle.seats} Seats</span><span className="dot">·</span>
                <span><Fuel size={12} /> {vehicle.fuel}</span><span className="dot">·</span>
                <span><Settings2 size={12} /> {vehicle.transmission}</span>
              </div>
            </div>
            <StatusBadge status={vehicle.status} />
          </div>

          {vehicle.description && <p style={{ marginTop: 10 }}>{vehicle.description}</p>}

          <h3 className="sub-head">Specifications</h3>
          <div className="specs-grid">
            {specs.map(([k, v]) => (
              <div className="spec-cell" key={k}><div className="spec-k">{k}</div><div className="spec-v">{v}</div></div>
            ))}
          </div>

          <h3 className="sub-head">Rental Rules</h3>
          <Accordion items={RULES} />

          <h3 className="sub-head">Required Documents</h3>
          <div className="doc-chips">
            <span className="chip"><BadgeCheck size={14} /> Driving Licence</span>
            <span className="chip"><BadgeCheck size={14} /> Government ID</span>
            <span className="chip"><BadgeCheck size={14} /> Selfie Verification</span>
          </div>
        </div>

        <div className="booking-calc">
          <div className="calc-price-row"><span className="v-price">{money(vehicle.dailyPrice)}</span><span className="v-price-unit">/day</span></div>
          <p className="calc-note" style={{ textAlign: "left", marginTop: -4, marginBottom: 12 }}>Transparent pricing — no security deposit.</p>

          <div className="calc-field">
            <label>Pickup Date</label>
            <input type="date" value={start} onChange={(e) => setStart(e.target.value)} />
          </div>
          <div className="calc-field">
            <label>Return Date</label>
            <input type="date" value={end} min={start} onChange={(e) => setEnd(e.target.value)} />
          </div>

          <div className="calc-breakdown">
            <div className="calc-row"><span>Daily Price</span><span>{money(vehicle.dailyPrice)}</span></div>
            <div className="calc-row"><span>Number of Days</span><span>{days}</span></div>
            <div className="calc-row"><span>Rental Cost</span><span>{money(pricing.rentalCost)}</span></div>
            {pricing.discount > 0 && <div className="calc-row discount"><span>{pricing.discountLabel}</span><span>-{money(pricing.discount)}</span></div>}
            <div className="calc-row"><span>Taxes &amp; Fees</span><span>{money(pricing.taxes)}</span></div>
            <div className="calc-row total"><span>Final Amount</span><span>{money(pricing.total)}</span></div>
          </div>

          <button
            className="btn btn-primary btn-lg"
            style={{ width: "100%" }}
            disabled={vehicle.status !== "available" || !start || !end || days < 1}
            onClick={() => navigate(`/booking/${vehicle.id}?start=${start}&end=${end}`)}
          >
            Proceed to Booking <ArrowRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
