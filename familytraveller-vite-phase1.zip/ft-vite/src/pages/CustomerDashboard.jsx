import React, { useEffect, useState } from "react";
import { Loader2, Download, Star } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { fetchCustomerBookings, cancelBooking, submitReview } from "../services/bookings";
import { money } from "../utils/pricing";

function isCancellable(booking) {
  if (["cancelled", "completed", "rejected"].includes(booking.bookingStatus)) return false;
  const hoursToPickup = (new Date(booking.pickupAt) - new Date()) / (1000 * 60 * 60);
  return hoursToPickup > 0;
}

function ReviewForm({ booking, onDone }) {
  const { user } = useAuth();
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    setBusy(true);
    try {
      await submitReview({ bookingId: booking.id, customerId: user.id, vehicleId: booking.vehicleId, rating, comment });
      onDone();
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="form-card" style={{ marginTop: 10 }}>
      <div className="form-field">
        <label>Rating</label>
        <div style={{ display: "flex", gap: 4 }}>
          {[1, 2, 3, 4, 5].map((n) => (
            <button key={n} onClick={() => setRating(n)} style={{ background: "none", border: "none", cursor: "pointer" }}>
              <Star size={20} fill={n <= rating ? "var(--amber)" : "none"} stroke="var(--amber)" />
            </button>
          ))}
        </div>
      </div>
      <div className="form-field">
        <label>Comment</label>
        <textarea rows={2} value={comment} onChange={(e) => setComment(e.target.value)} />
      </div>
      <button className="btn btn-primary" onClick={submit} disabled={busy}>{busy ? <Loader2 size={14} className="spin" /> : "Submit Review"}</button>
    </div>
  );
}

export default function CustomerDashboard() {
  const { user, profile } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reviewingId, setReviewingId] = useState(null);
  const [tab, setTab] = useState("bookings");

  const load = () => {
    setLoading(true);
    fetchCustomerBookings(user.id).then(setBookings).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [user.id]);

  const now = new Date();
  const upcoming = bookings.filter((b) => new Date(b.pickupAt) > now && b.bookingStatus === "confirmed");
  const active = bookings.filter((b) => new Date(b.pickupAt) <= now && new Date(b.returnAt) >= now && b.bookingStatus !== "cancelled");
  const past = bookings.filter((b) => new Date(b.returnAt) < now || ["completed", "cancelled", "rejected"].includes(b.bookingStatus));

  const handleCancel = async (id) => {
    await cancelBooking(id);
    load();
  };

  return (
    <div className="section">
      <div className="section-head"><div><span className="eyebrow">Your account</span><h2>Welcome, {profile?.full_name || "Customer"}</h2></div></div>

      <div className="stat-grid">
        <div className="stat-card"><div><span>Upcoming</span><strong>{upcoming.length}</strong></div></div>
        <div className="stat-card"><div><span>Active Rental</span><strong>{active.length}</strong></div></div>
        <div className="stat-card"><div><span>Past Bookings</span><strong>{past.length}</strong></div></div>
        <div className="stat-card"><div><span>Total Trips</span><strong>{bookings.length}</strong></div></div>
      </div>

      <div className="admin-tabs">
        {[["bookings", "My Bookings"], ["profile", "Profile"]].map(([id, label]) => (
          <button key={id} className={"admin-tab" + (tab === id ? " active" : "")} onClick={() => setTab(id)}>{label}</button>
        ))}
      </div>

      {tab === "profile" && (
        <div className="form-card">
          <div className="form-field"><label>Full Name</label><input value={profile?.full_name || ""} disabled /></div>
          <div className="form-field"><label>Email</label><input value={user.email || ""} disabled /></div>
          <div className="form-field"><label>Mobile</label><input value={profile?.mobile || ""} disabled /></div>
        </div>
      )}

      {tab === "bookings" && (
        loading ? <Loader2 size={20} className="spin" /> : (
          bookings.length === 0 ? <div className="empty-state">No bookings yet — go find your next ride.</div> : (
            <div className="table-wrap">
              <table className="admin-table">
                <thead><tr><th>Booking</th><th>Vehicle</th><th>Dates</th><th>Amount</th><th>Status</th><th></th></tr></thead>
                <tbody>
                  {bookings.map((b) => (
                    <React.Fragment key={b.id}>
                      <tr>
                        <td>{b.code}</td>
                        <td>{b.vehicle?.name || "—"}</td>
                        <td>{new Date(b.pickupAt).toLocaleDateString("en-IN")} → {new Date(b.returnAt).toLocaleDateString("en-IN")}</td>
                        <td>{money(b.totalAmount)}</td>
                        <td><span className="chip">{b.bookingStatus}</span></td>
                        <td style={{ display: "flex", gap: 6 }}>
                          {isCancellable(b) && <button className="btn btn-ghost" onClick={() => handleCancel(b.id)}>Cancel</button>}
                          {b.bookingStatus === "completed" && (
                            <button className="btn btn-ghost" onClick={() => setReviewingId(reviewingId === b.id ? null : b.id)}>Review</button>
                          )}
                        </td>
                      </tr>
                      {reviewingId === b.id && (
                        <tr><td colSpan={6}><ReviewForm booking={b} onDone={() => { setReviewingId(null); load(); }} /></td></tr>
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          )
        )
      )}
    </div>
  );
}
