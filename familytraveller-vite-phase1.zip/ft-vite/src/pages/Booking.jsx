import React, { useEffect, useState } from "react";
import { useParams, useSearchParams, useNavigate, Link } from "react-router-dom";
import { Loader2 } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import AuthModal from "../components/AuthModal";
import VehicleIllustration from "../components/VehicleIllustration";
import { fetchVehicleById } from "../services/vehicles";
import { createBooking } from "../services/bookings";
import { createRazorpayOrder, openRazorpayCheckout } from "../services/payments";
import { computePricing, daysBetween, money } from "../utils/pricing";
import { validateBookingForm, isEmpty } from "../utils/validation";

const LOCATIONS = (import.meta.env.VITE_SUPPORT_CITIES || "Mumbai,Pune,Bengaluru").split(",").filter(Boolean);

export default function Booking() {
  const { vehicleId } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const auth = useAuth();

  const [vehicle, setVehicle] = useState(null);
  const [loadingVehicle, setLoadingVehicle] = useState(true);
  const [form, setForm] = useState({
    fullName: auth.profile?.full_name || "", mobile: "", email: auth.user?.email || "",
    pickupLocation: LOCATIONS[0] || "",
    pickupDate: searchParams.get("start") || "", returnDate: searchParams.get("end") || "",
    pickupTime: "10:00", returnTime: "10:00",
    licence: "", idType: "Aadhaar", idNumber: "",
    notes: "", coupon: "",
  });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [apiError, setApiError] = useState("");
  const [showAuth, setShowAuth] = useState(false);

  useEffect(() => {
    fetchVehicleById(vehicleId).then(setVehicle).catch((e) => setApiError(e.message)).finally(() => setLoadingVehicle(false));
  }, [vehicleId]);

  const update = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const days = daysBetween(form.pickupDate, form.returnDate);
  const pricing = vehicle ? computePricing(vehicle, days || 1, form.coupon) : null;

  const submit = async () => {
    const validationErrors = validateBookingForm(form, days);
    setErrors(validationErrors);
    if (!isEmpty(validationErrors)) return;

    if (!auth.user) { setShowAuth(true); return; }

    setApiError(""); setSubmitting(true);
    try {
      const pickupAt = new Date(`${form.pickupDate}T${form.pickupTime}:00`).toISOString();
      const returnAt = new Date(`${form.returnDate}T${form.returnTime}:00`).toISOString();

      const { booking } = await createBooking({
        vehicle,
        customerId: auth.user.id,
        pickupLocation: form.pickupLocation,
        returnLocation: form.pickupLocation,
        pickupAt, returnAt, days,
        couponCode: form.coupon,
        drivingLicenceNo: form.licence,
        idProofType: form.idType,
        idProofNumber: form.idNumber,
        notes: form.notes,
      });

      const order = await createRazorpayOrder(booking.id);

      await openRazorpayCheckout({
        order: { ...order, bookingCode: booking.code },
        prefill: { name: form.fullName, email: form.email, contact: form.mobile },
        onSuccess: () => navigate(`/confirmation/${booking.id}`),
        onDismiss: () => setApiError("Payment was not completed. Your booking is held as pending — you can retry from your dashboard."),
      });
    } catch (err) {
      setApiError(err.message || "Something went wrong creating your booking.");
    } finally {
      setSubmitting(false);
    }
  };

  if (loadingVehicle) return <div className="section"><Loader2 size={20} className="spin" /></div>;
  if (!vehicle) return <div className="section"><p>Vehicle not found.</p></div>;

  return (
    <div className="section">
      <Link className="link-arrow back" to={`/vehicles/${vehicle.id}`}>← Back to vehicle</Link>
      <div className="section-head"><div><span className="eyebrow">Almost there</span><h2>Confirm Your Booking</h2></div></div>

      <div className="booking-layout">
        <div className="form-card">
          <h3 className="sub-head" style={{ marginTop: 0 }}>Your Details</h3>
          <div className="form-grid">
            <div className="form-field">
              <label>Full Name</label>
              <input value={form.fullName} onChange={update("fullName")} placeholder="As per driving licence" />
              {errors.fullName && <span className="err">{errors.fullName}</span>}
            </div>
            <div className="form-field">
              <label>Mobile Number</label>
              <input value={form.mobile} onChange={update("mobile")} placeholder="10-digit mobile number" />
              {errors.mobile && <span className="err">{errors.mobile}</span>}
            </div>
            <div className="form-field">
              <label>Email</label>
              <input value={form.email} onChange={update("email")} placeholder="you@example.com" />
              {errors.email && <span className="err">{errors.email}</span>}
            </div>
            <div className="form-field">
              <label>Pickup Location</label>
              <select value={form.pickupLocation} onChange={update("pickupLocation")}>
                {LOCATIONS.map((l) => <option key={l} value={l}>{l}</option>)}
              </select>
            </div>
            <div className="form-field">
              <label>Pickup Date</label>
              <input type="date" value={form.pickupDate} onChange={update("pickupDate")} />
              {errors.pickupDate && <span className="err">{errors.pickupDate}</span>}
            </div>
            <div className="form-field">
              <label>Pickup Time</label>
              <input type="time" value={form.pickupTime} onChange={update("pickupTime")} />
            </div>
            <div className="form-field">
              <label>Return Date</label>
              <input type="date" value={form.returnDate} min={form.pickupDate} onChange={update("returnDate")} />
              {errors.returnDate && <span className="err">{errors.returnDate}</span>}
            </div>
            <div className="form-field">
              <label>Return Time</label>
              <input type="time" value={form.returnTime} onChange={update("returnTime")} />
            </div>
          </div>

          <h3 className="sub-head">Selected Vehicle</h3>
          <div className="selected-vehicle-row">
            <VehicleIllustration type={vehicle.type} tone="var(--asphalt)" size={56} />
            <div>
              <div style={{ fontWeight: 700 }}>{vehicle.name}</div>
              <div className="v-tags"><span>{vehicle.type}</span><span className="dot">·</span><span>{money(vehicle.dailyPrice)}/day</span></div>
            </div>
          </div>

          <h3 className="sub-head">Identity Verification</h3>
          <p className="verify-note">Your documents are used only for rental verification and are stored privately.</p>
          <div className="form-grid">
            <div className="form-field">
              <label>Driving Licence Number</label>
              <input value={form.licence} onChange={update("licence")} placeholder="e.g. MH12 20230012345" />
              {errors.licence && <span className="err">{errors.licence}</span>}
            </div>
            <div className="form-field">
              <label>ID Proof Type</label>
              <select value={form.idType} onChange={update("idType")}>
                <option>Aadhaar</option><option>Passport</option><option>Voter ID</option>
              </select>
            </div>
            <div className="form-field">
              <label>ID Proof Number</label>
              <input value={form.idNumber} onChange={update("idNumber")} placeholder="ID number" />
              {errors.idNumber && <span className="err">{errors.idNumber}</span>}
            </div>
          </div>

          <div className="form-field">
            <label>Additional Notes</label>
            <textarea rows={3} value={form.notes} onChange={update("notes")} placeholder="Anything we should know?" />
          </div>
        </div>

        <div className="summary-card">
          <h3 className="sub-head" style={{ marginTop: 0 }}>Price Summary</h3>
          <div className="form-field">
            <label>Coupon Code</label>
            <input value={form.coupon} onChange={update("coupon")} placeholder="Try FIRST10" />
          </div>
          {pricing && (
            <div className="calc-breakdown">
              <div className="calc-row"><span>Rental Cost ({pricing.days} day{pricing.days !== 1 ? "s" : ""})</span><span>{money(pricing.rentalCost)}</span></div>
              {pricing.discount > 0 && <div className="calc-row discount"><span>{pricing.discountLabel}</span><span>-{money(pricing.discount)}</span></div>}
              {pricing.couponDiscount > 0 && <div className="calc-row discount"><span>Coupon FIRST10</span><span>-{money(pricing.couponDiscount)}</span></div>}
              <div className="calc-row"><span>Taxes &amp; Fees</span><span>{money(pricing.taxes)}</span></div>
              <div className="calc-row"><span>Additional Charges</span><span>{money(0)}</span></div>
              <div className="calc-row total"><span>Final Amount</span><span>{money(pricing.total)}</span></div>
            </div>
          )}
          {apiError && <div className="err" style={{ marginTop: 10 }}>{apiError}</div>}
          <button className="btn btn-primary btn-lg" style={{ width: "100%", marginTop: 14 }} onClick={submit} disabled={submitting}>
            {submitting ? <Loader2 size={16} className="spin" /> : "Confirm & Pay"}
          </button>
          <div className="calc-note">You'll be taken to Razorpay to complete payment securely. No security deposit is charged.</div>
        </div>
      </div>

      {showAuth && <AuthModal onClose={() => setShowAuth(false)} onSuccess={() => setTimeout(submit, 200)} />}
    </div>
  );
}
