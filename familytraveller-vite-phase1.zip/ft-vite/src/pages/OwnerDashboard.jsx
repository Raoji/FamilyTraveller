import React from "react";

/**
 * NOT YET IMPLEMENTED. This is a Phase 2 item (see Sections 13 and 26 of
 * the spec): vehicle CRUD, image upload, booking accept/reject, earnings.
 * The database schema already supports it (vehicles.owner_id,
 * bookings.owner_id, the vehicle-images bucket, and the RLS policies that
 * scope an owner to their own vehicles/bookings) — this page just doesn't
 * have a UI built on top of it yet. Wiring it up is mostly reusing the
 * patterns already in AdminDashboard.jsx and services/vehicles.js.
 */
export default function OwnerDashboard() {
  return (
    <div className="section">
      <div className="empty-state">
        <p style={{ marginBottom: 8, fontWeight: 600 }}>Owner Dashboard — coming in Phase 2</p>
        <p>The database and permissions for vehicle owners already exist. This screen (add/edit vehicles, upload photos, accept or reject bookings, view earnings) is the next piece to build.</p>
      </div>
    </div>
  );
}
