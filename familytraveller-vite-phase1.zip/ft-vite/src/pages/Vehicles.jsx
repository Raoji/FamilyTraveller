import React, { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { SlidersHorizontal, Loader2 } from "lucide-react";
import VehicleCard from "../components/VehicleCard";
import { fetchVehicles } from "../services/vehicles";
import { money } from "../utils/pricing";

export default function Vehicles() {
  const [searchParams] = useSearchParams();
  const [allVehicles, setAllVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [filters, setFilters] = useState({
    types: searchParams.get("type") ? [searchParams.get("type")] : [],
    maxPrice: 4000,
    fuels: [],
    transmission: "Any",
    minSeats: 2,
    brand: "Any",
    onlyAvailable: true,
  });

  useEffect(() => {
    setLoading(true);
    fetchVehicles({ city: searchParams.get("city") || undefined })
      .then(setAllVehicles)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [searchParams]);

  const brands = useMemo(() => [...new Set(allVehicles.map((v) => v.brand).filter(Boolean))], [allVehicles]);

  const filtered = allVehicles.filter((v) => {
    if (filters.types.length && !filters.types.includes(v.type)) return false;
    if (v.dailyPrice > filters.maxPrice) return false;
    if (filters.fuels.length && !filters.fuels.includes(v.fuel)) return false;
    if (filters.transmission !== "Any" && v.transmission !== filters.transmission) return false;
    if (v.seats < filters.minSeats) return false;
    if (filters.brand !== "Any" && v.brand !== filters.brand) return false;
    if (filters.onlyAvailable && v.status !== "available") return false;
    return true;
  });

  const toggleType = (t) => setFilters((f) => ({ ...f, types: f.types.includes(t) ? f.types.filter((x) => x !== t) : [...f.types, t] }));
  const toggleFuel = (t) => setFilters((f) => ({ ...f, fuels: f.fuels.includes(t) ? f.fuels.filter((x) => x !== t) : [...f.fuels, t] }));

  return (
    <div className="section">
      <div className="section-head">
        <div><span className="eyebrow">Marketplace</span><h2>Available Vehicles</h2></div>
        <div className="result-count">{loading ? "Loading…" : `${filtered.length} vehicle${filtered.length !== 1 ? "s" : ""} found`}</div>
      </div>

      {error && <div className="err" style={{ marginBottom: 16 }}>{error}</div>}

      <div className="listing-layout">
        <aside className="filters">
          <div className="filters-head"><SlidersHorizontal size={16} /> Filters</div>

          <div className="filter-group">
            <div className="filter-label">Vehicle Type</div>
            {["Hatchback", "SUV", "MUV", "Bike", "Scooter"].map((t) => (
              <label className="check-row" key={t}>
                <input type="checkbox" checked={filters.types.includes(t)} onChange={() => toggleType(t)} /> {t}
              </label>
            ))}
          </div>

          <div className="filter-group">
            <div className="filter-label">Price per day: up to {money(filters.maxPrice)}</div>
            <input type="range" min="400" max="4000" step="100" value={filters.maxPrice}
              onChange={(e) => setFilters((f) => ({ ...f, maxPrice: Number(e.target.value) }))} />
          </div>

          <div className="filter-group">
            <div className="filter-label">Fuel Type</div>
            {["Petrol", "Diesel", "Electric"].map((t) => (
              <label className="check-row" key={t}>
                <input type="checkbox" checked={filters.fuels.includes(t)} onChange={() => toggleFuel(t)} /> {t}
              </label>
            ))}
          </div>

          <div className="filter-group">
            <div className="filter-label">Transmission</div>
            <select value={filters.transmission} onChange={(e) => setFilters((f) => ({ ...f, transmission: e.target.value }))}>
              <option value="Any">Any</option><option value="Manual">Manual</option><option value="Automatic">Automatic</option>
            </select>
          </div>

          <div className="filter-group">
            <div className="filter-label">Minimum Seats</div>
            <select value={filters.minSeats} onChange={(e) => setFilters((f) => ({ ...f, minSeats: Number(e.target.value) }))}>
              {[2, 4, 5, 7].map((s) => <option key={s} value={s}>{s}+</option>)}
            </select>
          </div>

          <div className="filter-group">
            <div className="filter-label">Brand</div>
            <select value={filters.brand} onChange={(e) => setFilters((f) => ({ ...f, brand: e.target.value }))}>
              <option value="Any">Any Brand</option>
              {brands.map((b) => <option key={b} value={b}>{b}</option>)}
            </select>
          </div>

          <label className="check-row">
            <input type="checkbox" checked={filters.onlyAvailable} onChange={(e) => setFilters((f) => ({ ...f, onlyAvailable: e.target.checked }))} />
            Show available only
          </label>
        </aside>

        <div className="vehicle-grid">
          {loading && <div className="empty-state"><Loader2 size={18} className="spin" /></div>}
          {!loading && filtered.length === 0 && <div className="empty-state">No vehicles match these filters. Try widening your search.</div>}
          {!loading && filtered.map((v) => <VehicleCard key={v.id} vehicle={v} />)}
        </div>
      </div>
    </div>
  );
}
