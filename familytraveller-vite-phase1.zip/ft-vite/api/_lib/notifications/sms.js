const MSG91_URL = "https://api.msg91.com/api/v5/flow/";

async function sendSms({ mobile, flowId, variables }) {
  if (!flowId) return; // template not configured yet — skip rather than throw
  const res = await fetch(MSG91_URL, {
    method: "POST",
    headers: { authkey: process.env.MSG91_API_KEY, "Content-Type": "application/json" },
    body: JSON.stringify({ flow_id: flowId, mobiles: `91${mobile}`, ...variables }),
  });
  if (!res.ok) throw new Error(`MSG91 error (${res.status}): ${await res.text()}`);
  return res.json();
}

export async function sendBookingConfirmationSms({ mobile, booking, vehicle }) {
  return sendSms({
    mobile,
    flowId: process.env.MSG91_FLOW_BOOKING_CONFIRMED,
    variables: { booking_code: booking.booking_code, vehicle_name: vehicle.name },
  });
}

export async function sendCancellationSms({ mobile, booking }) {
  return sendSms({
    mobile,
    flowId: process.env.MSG91_FLOW_BOOKING_CANCELLED,
    variables: { booking_code: booking.booking_code },
  });
}
