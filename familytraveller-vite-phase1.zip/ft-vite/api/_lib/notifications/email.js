const RESEND_URL = "https://api.resend.com/emails";
const FROM_ADDRESS = "FamilyTraveller <bookings@familytraveller.in>";

async function sendEmail({ to, subject, html }) {
  const res = await fetch(RESEND_URL, {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: FROM_ADDRESS, to, subject, html }),
  });
  if (!res.ok) throw new Error(`Resend error (${res.status}): ${await res.text()}`);
  return res.json();
}

export async function sendBookingConfirmationEmail({ to, booking, vehicle }) {
  const html = `
    <h2>Booking Confirmed 🎉</h2>
    <table cellpadding="6">
      <tr><td><strong>Booking ID</strong></td><td>${booking.booking_code}</td></tr>
      <tr><td><strong>Vehicle</strong></td><td>${vehicle.name}</td></tr>
      <tr><td><strong>Pickup</strong></td><td>${booking.pickup_location} · ${new Date(booking.pickup_at).toLocaleString("en-IN")}</td></tr>
      <tr><td><strong>Return</strong></td><td>${new Date(booking.return_at).toLocaleString("en-IN")}</td></tr>
      <tr><td><strong>Final Amount</strong></td><td>₹${booking.total_amount}</td></tr>
    </table>
    <p>No security deposit was charged. Drive safe!</p>
  `;
  return sendEmail({ to, subject: `Booking Confirmed — ${booking.booking_code}`, html });
}

export async function sendCancellationEmail({ to, booking }) {
  const html = `<p>Your booking <strong>${booking.booking_code}</strong> has been cancelled.</p>`;
  return sendEmail({ to, subject: `Booking Cancelled — ${booking.booking_code}`, html });
}
