import { createClient } from "@supabase/supabase-js";

/**
 * Service-role client — bypasses RLS. Used ONLY inside /api serverless
 * functions, never imported into anything under /src (the browser bundle).
 * Requires SUPABASE_SERVICE_ROLE_KEY, which must never be prefixed VITE_.
 */
export function supabaseAdmin() {
  return createClient(
    process.env.VITE_SUPABASE_URL, // safe to reuse; it's a public URL, not a secret
    process.env.SUPABASE_SERVICE_ROLE_KEY,
    { auth: { persistSession: false } }
  );
}
