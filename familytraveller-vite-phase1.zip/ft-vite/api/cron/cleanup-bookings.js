import { supabaseAdmin } from "../_lib/supabaseAdmin.js";

/**
 * GET /api/cron/cleanup-bookings
 * Cancels bookings abandoned mid-checkout and releases their date hold.
 * Schedule via Vercel Cron (see vercel.json) hitting this route every
 * 10 minutes, or via Supabase pg_cron calling cleanup_stale_bookings()
 * directly in the database — either works, pick one.
 */
export default async function handler(req, res) {
  const authHeader = req.headers.authorization || "";
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const admin = supabaseAdmin();
  const { data, error } = await admin.rpc("cleanup_stale_bookings", { p_older_than_minutes: 30 });

  if (error) return res.status(500).json({ error: error.message });
  return res.status(200).json({ cancelledCount: data });
}
