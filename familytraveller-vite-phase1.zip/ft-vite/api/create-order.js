import Razorpay from "razorpay";
import { supabaseAdmin } from "./_lib/supabaseAdmin.js";

/**
 * POST /api/create-order
 * Body: { bookingId }
 *
 * Creates a Razorpay Order for the booking's total_amount — which, per
 * the pricing engine (src/utils/pricing.js) and the bookings table
 * (migration 001), never includes a security deposit. This function
 * only ever creates an order; it never marks anything as paid — that
 * happens exclusively in /api/webhooks/razorpay after signature
 * verification.
 */
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { bookingId } = req.body;
  if (!bookingId) return res.status(400).json({ error: "bookingId is required" });

  const admin = supabaseAdmin();
  const { data: booking, error } = await admin
    .from("bookings")
    .select("id, total_amount, payment_status, booking_code")
    .eq("id", bookingId)
    .single();

  if (error || !booking) return res.status(404).json({ error: "Booking not found" });
  if (booking.payment_status === "paid") return res.status(409).json({ error: "Booking is already paid" });

  const amountPaise = Math.round(Number(booking.total_amount) * 100);

  const razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID,
    key_secret: process.env.RAZORPAY_KEY_SECRET,
  });

  const order = await razorpay.orders.create({
    amount: amountPaise,
    currency: "INR",
    receipt: booking.booking_code,
    notes: { booking_id: booking.id },
  });

  await admin.from("payments").insert({
    booking_id: booking.id,
    razorpay_order_id: order.id,
    amount: booking.total_amount,
    status: "created",
    raw_payload: order,
  });

  return res.status(200).json({
    orderId: order.id,
    amount: order.amount,
    currency: order.currency,
    keyId: process.env.RAZORPAY_KEY_ID,
  });
}
