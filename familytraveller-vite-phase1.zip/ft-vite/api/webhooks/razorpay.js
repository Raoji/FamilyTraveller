import crypto from "crypto";
import { supabaseAdmin } from "../_lib/supabaseAdmin.js";
import { sendBookingConfirmationEmail, sendCancellationEmail } from "../_lib/notifications/email.js";
import { sendBookingConfirmationSms, sendCancellationSms } from "../_lib/notifications/sms.js";

/**
 * POST /api/webhooks/razorpay
 *
 * This is the ONLY place a booking's payment_status becomes "paid".
 * Configure this URL in the Razorpay Dashboard → Settings → Webhooks,
 * subscribed to payment.captured and payment.failed. Never trust the
 * frontend Razorpay success callback alone — it can be closed, dropped,
 * or spoofed; this signature-verified server event is the source of truth.
 *
 * The `config` export below disables Vercel's automatic JSON body
 * parsing for this function, because signature verification needs the
 * EXACT raw bytes Razorpay sent — parsing and re-stringifying the JSON
 * can produce a different byte sequence and make every signature check
 * fail. readRawBody() below reads the untouched request stream instead.
 */
export const config = { api: { bodyParser: false } };

function readRawBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (chunk) => { data += chunk; });
    req.on("end", () => resolve(data));
    req.on("error", reject);
  });
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const rawBody = await readRawBody(req);
  const signature = req.headers["x-razorpay-signature"];

  const expected = crypto
    .createHmac("sha256", process.env.RAZORPAY_WEBHOOK_SECRET)
    .update(rawBody)
    .digest("hex");

  if (signature !== expected) return res.status(400).json({ error: "Invalid signature" });

  const event = JSON.parse(rawBody);
  const admin = supabaseAdmin();

  if (event.event === "payment.captured") {
    const payment = event.payload.payment.entity;
    const bookingId = payment.notes?.booking_id;

    const { data: existing } = await admin
      .from("payments").select("id").eq("razorpay_payment_id", payment.id).maybeSingle();

    if (!existing) {
      await admin.from("payments").insert({
        booking_id: bookingId,
        razorpay_order_id: payment.order_id,
        razorpay_payment_id: payment.id,
        amount: payment.amount / 100,
        status: "captured",
        raw_payload: payment,
      });

      await admin.from("bookings")
        .update({ booking_status: "confirmed", payment_status: "paid", updated_at: new Date().toISOString() })
        .eq("id", bookingId);

      await admin.from("audit_log").insert({
        action: "payment.captured",
        target_table: "bookings",
        target_id: bookingId,
        detail: { razorpay_payment_id: payment.id, amount: payment.amount / 100 },
      });

      const { data: booking } = await admin
        .from("bookings")
        .select("*, vehicles(*), customer:profiles!bookings_customer_id_fkey(full_name, mobile)")
        .eq("id", bookingId)
        .single();

      if (booking) {
        const mobile = booking.customer?.mobile;
        await Promise.allSettled([
          payment.email && sendBookingConfirmationEmail({ to: payment.email, booking, vehicle: booking.vehicles }),
          mobile && sendBookingConfirmationSms({ mobile, booking, vehicle: booking.vehicles }),
        ]);
      }
    }
  }

  if (event.event === "payment.failed") {
    const payment = event.payload.payment.entity;
    const bookingId = payment.notes?.booking_id;

    await admin.from("payments").insert({
      booking_id: bookingId,
      razorpay_order_id: payment.order_id,
      razorpay_payment_id: payment.id,
      amount: payment.amount / 100,
      status: "failed",
      raw_payload: payment,
    });

    if (bookingId) {
      await admin.from("vehicle_blocks").delete().eq("booking_id", bookingId);
      const { data: cancelled } = await admin
        .from("bookings")
        .update({ booking_status: "cancelled", updated_at: new Date().toISOString() })
        .eq("id", bookingId)
        .select("*, customer:profiles!bookings_customer_id_fkey(mobile)")
        .single();

      if (cancelled) {
        const mobile = cancelled.customer?.mobile;
        await Promise.allSettled([
          payment.email && sendCancellationEmail({ to: payment.email, booking: cancelled }),
          mobile && sendCancellationSms({ mobile, booking: cancelled }),
        ]);
      }
    }
  }

  return res.status(200).json({ received: true });
}
