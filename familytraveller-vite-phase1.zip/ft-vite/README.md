# FamilyTraveller — Phase 1 (Vite + Supabase + Razorpay, no security deposit)

Phase 1 delivers a working, testable customer + admin platform. Owner and
driver dashboards are scaffolded (routes, role, empty-state screens) but
their real functionality is Phase 2 — see "Remaining limitations" below.
Nothing here is mocked and claimed as done: if a screen says "coming in
Phase 2," it means exactly that.

## 1. Files created

```
package.json, vite.config.js, index.html, .env.example, vercel.json, .gitignore

src/main.jsx, src/App.jsx
src/styles/index.css

src/context/AuthContext.jsx

src/services/supabase.js       - Supabase client + fetch helper for /api
src/services/vehicles.js       - vehicle CRUD + listing
src/services/bookings.js       - booking creation (RPC), fetch, cancel, review
src/services/payments.js       - Razorpay order + checkout
src/services/storage.js        - document + vehicle image uploads

src/utils/pricing.js           - the ONE pricing function, no deposit
src/utils/validation.js
src/utils/availability.js      - frontend pre-check only, DB is authoritative
src/utils/constants.js         - rental rules & FAQ copy

src/components/Header.jsx
src/components/Footer.jsx
src/components/VehicleCard.jsx
src/components/VehicleIllustration.jsx
src/components/AuthModal.jsx
src/components/WhatsAppButton.jsx
src/components/Accordion.jsx
src/components/ProtectedRoute.jsx

src/pages/Home.jsx
src/pages/Vehicles.jsx
src/pages/VehicleDetails.jsx
src/pages/Booking.jsx
src/pages/Confirmation.jsx
src/pages/CustomerDashboard.jsx
src/pages/AdminDashboard.jsx
src/pages/OwnerDashboard.jsx    - Phase 2 placeholder, honestly labeled
src/pages/DriverDashboard.jsx   - Phase 2 placeholder, honestly labeled
src/pages/StaticPages.jsx       - How It Works, Rules, FAQ, Contact, Legal

api/_lib/supabaseAdmin.js
api/_lib/notifications/email.js
api/_lib/notifications/sms.js
api/create-order.js             - Razorpay order creation (needs secret key)
api/webhooks/razorpay.js        - the ONLY place payment_status becomes "paid"
api/cron/cleanup-bookings.js    - releases holds on abandoned bookings

supabase/migrations/001_init.sql
```

## 2. Files modified

None — this is a fresh Vite scaffold replacing the single-file Next.js
version from earlier in this project. There was no existing Vite codebase
to preserve; everything above is new, built to the spec you provided
(no deposit, roles, Vite conventions).

## 3. Supabase SQL migrations

One file: `supabase/migrations/001_init.sql`. Run it once, top to bottom,
in the Supabase SQL editor. It creates every table, the `create_booking()`
and `cleanup_stale_bookings()` functions, all RLS policies, the two
storage buckets (`vehicle-images` public, `customer-documents` private),
and seeds 3 sample verified vehicles.

**No `deposit` / `security_deposit` / `deposit_amount` column exists
anywhere in this schema.**

## 4. Environment variables required

See `.env.example` for the full list with comments. Summary:

**Frontend (`VITE_` prefix — reaches the browser bundle):**
`VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `VITE_CONTACT_PHONE`,
`VITE_CONTACT_WHATSAPP`, `VITE_CONTACT_EMAIL`, `VITE_SUPPORT_CITIES`,
`VITE_SUPPORT_HOURS`

**Serverless functions only (`/api` — never prefix these `VITE_`):**
`SUPABASE_SERVICE_ROLE_KEY`, `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`,
`RAZORPAY_WEBHOOK_SECRET`, `CRON_SECRET`, `RESEND_API_KEY`,
`MSG91_API_KEY`, `MSG91_FLOW_BOOKING_CONFIRMED`, `MSG91_FLOW_BOOKING_CANCELLED`

## 5. Commands to run

```bash
npm install
npm run dev        # http://localhost:5173

npm run build       # production build → dist/
npm run preview     # serve the production build locally
npm run lint
```

(The spec mentioned `npm.cmd install` for Windows — same commands, just
`npm.cmd` instead of `npm` in a Windows terminal that needs the explicit
extension.)

## 6. Supabase setup steps

1. Create a project at supabase.com.
2. SQL Editor → paste and run `supabase/migrations/001_init.sql`.
3. Authentication → Providers → enable Email.
4. Sign up once through the app (any role), then promote that account to
   admin manually — public sign-up can never create an admin account:
   ```sql
   update profiles set role = 'admin' where id = '<your-user-uuid>';
   ```
5. Copy Project URL + anon key into `.env.local` as `VITE_SUPABASE_URL`
   / `VITE_SUPABASE_ANON_KEY`. Copy the service role key in as
   `SUPABASE_SERVICE_ROLE_KEY` (used only by `/api`, never sent to Supabase
   from the frontend directly — the frontend uses the anon key + RLS).

## 7. Razorpay setup steps

1. Sign up at razorpay.com, stay in **Test Mode**.
2. Settings → API Keys → copy into `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET`.
3. Settings → Webhooks → add `https://<your-domain>/api/webhooks/razorpay`,
   subscribe to `payment.captured` and `payment.failed`, copy the
   generated secret into `RAZORPAY_WEBHOOK_SECRET`.
4. For local testing, tunnel your dev server (ngrok/cloudflared) so
   Razorpay's webhook can reach `localhost`.
5. Pay with Razorpay's published test card/UPI numbers — never use a
   real card against test-mode keys.

## 8. Test accounts / roles required

Sign up three separate accounts to test the current build:

| Role | How to create | What you can test now |
|---|---|---|
| customer | Sign up, choose "Customer" | Full booking flow, dashboard, cancel, review |
| admin | Sign up any role, then run the SQL in step 6.4 | Vehicle verification, status changes, booking status, revenue |
| vehicle_owner / driver | Sign up, choose the role | Only the "coming in Phase 2" placeholder screen — see below |

## 9. Remaining limitations (Phase 2)

Honest, not exhaustive:

- **Owner Dashboard** — UI not built. RLS, `owner_id` columns, and the
  `vehicle-images` bucket already support it; needs a form + table UI
  mirroring `AdminDashboard.jsx`.
- **Driver Dashboard** — UI not built; lower priority since the platform
  is primarily self-drive.
- **Vehicle image upload UI** — `services/storage.js` has the upload
  function; no owner-facing form calls it yet.
- **Database-enforced availability boundary rule** — the exclusion
  constraint prevents any overlap; it does not yet encode a specific
  "same-day back-to-back OK" boundary rule if you want one different
  from strict `return_at > pickup_at` non-overlap. Confirm your exact
  boundary policy before launch and adjust the constraint if needed.
- **Rate limiting** — booking/auth endpoints have none yet.
- **Refunds** — Razorpay Refunds API not integrated.
- **Password reset UI** — Supabase supports it; no frontend screen yet.
- **Real vehicle photos** — 3 seed vehicles use the SVG illustration
  fallback; no photos uploaded.
- **Legal pages** — Terms/Privacy/Cancellation are placeholder text
  flagged for counsel review, not launch-ready legal text.
- **Contact info** — pulled from env vars, currently unset; fill in
  `.env.local` with your real numbers before treating this as live.
