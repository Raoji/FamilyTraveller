-- ============================================================
-- FamilyTraveller — Database Schema (Phase 1: no deposit, roles)
-- Run in the Supabase SQL editor, top to bottom.
-- ============================================================

create extension if not exists "uuid-ossp";
create extension if not exists btree_gist;

-- ------------------------------------------------------------
-- PROFILES
-- ------------------------------------------------------------
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  mobile text unique,
  -- Public sign-up can only ever create 'customer' or 'driver' or
  -- 'vehicle_owner' rows — see handle_new_user() below. 'admin' is
  -- never set from a client request; promote manually in SQL:
  --   update profiles set role = 'admin' where id = '<uuid>';
  role text not null default 'customer' check (role in ('customer','driver','vehicle_owner','admin')),
  is_blocked boolean not null default false,
  created_at timestamptz not null default now()
);

create function handle_new_user() returns trigger as $$
declare
  requested_role text;
begin
  requested_role := coalesce(new.raw_user_meta_data->>'role', 'customer');
  if requested_role not in ('customer','driver','vehicle_owner') then
    requested_role := 'customer'; -- admin can never be self-assigned at signup
  end if;

  insert into profiles (id, full_name, mobile, role)
  values (new.id, new.raw_user_meta_data->>'full_name', new.phone, requested_role);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_user();

-- ------------------------------------------------------------
-- VEHICLES  (no deposit column, anywhere)
-- ------------------------------------------------------------
create table vehicles (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  brand text,
  model text,
  year int,
  type text not null check (type in ('Hatchback','Sedan','SUV','MUV','Bike','Scooter')),
  seats int,
  fuel text check (fuel in ('Petrol','Diesel','Electric','CNG')),
  transmission text check (transmission in ('Manual','Automatic')),
  mileage text,
  ac boolean default true,
  luggage text,
  description text,
  daily_price numeric(10,2) not null check (daily_price > 0),
  status text not null default 'available' check (status in ('available','booked','maintenance')),
  verification_status text not null default 'pending' check (verification_status in ('pending','under_review','verified','rejected')),
  city text not null,
  owner_id uuid references profiles(id),
  created_at timestamptz not null default now()
);

create table vehicle_images (
  id uuid primary key default uuid_generate_v4(),
  vehicle_id uuid not null references vehicles(id) on delete cascade,
  storage_path text not null, -- path inside the "vehicle-images" bucket
  is_main boolean not null default false,
  sort_order int default 0
);

-- ------------------------------------------------------------
-- COUPONS
-- ------------------------------------------------------------
create table coupons (
  code text primary key,
  discount_percent numeric(5,2) not null check (discount_percent between 0 and 100),
  active boolean not null default true,
  valid_until date
);

insert into coupons (code, discount_percent, valid_until) values ('FIRST10', 10, null);

-- ------------------------------------------------------------
-- BOOKINGS  — no deposit field anywhere
-- ------------------------------------------------------------
create table bookings (
  id uuid primary key default uuid_generate_v4(),
  booking_code text unique not null,
  customer_id uuid not null references profiles(id),
  vehicle_id uuid not null references vehicles(id),
  owner_id uuid references profiles(id),
  pickup_location text not null,
  return_location text,
  pickup_at timestamptz not null,
  return_at timestamptz not null,
  rental_days int not null,
  rental_amount numeric(10,2) not null,
  discount_amount numeric(10,2) not null default 0,
  coupon_code text references coupons(code),
  coupon_discount numeric(10,2) not null default 0,
  tax_amount numeric(10,2) not null default 0,
  additional_charges numeric(10,2) not null default 0,
  total_amount numeric(10,2) not null,
  payment_status text not null default 'pending' check (payment_status in ('pending','paid','failed','refunded')),
  booking_status text not null default 'pending' check (booking_status in ('pending','confirmed','active','completed','cancelled','rejected')),
  driving_licence_no text not null,
  id_proof_type text,
  id_proof_number text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint valid_dates check (return_at > pickup_at)
);

-- ------------------------------------------------------------
-- VEHICLE_BLOCKS — overlap-proof availability
-- ------------------------------------------------------------
create table vehicle_blocks (
  id uuid primary key default uuid_generate_v4(),
  vehicle_id uuid not null references vehicles(id) on delete cascade,
  start_at timestamptz not null,
  end_at timestamptz not null,
  reason text not null default 'booking' check (reason in ('booking','maintenance')),
  booking_id uuid references bookings(id),
  constraint no_overlapping_blocks exclude using gist (
    vehicle_id with =,
    tstzrange(start_at, end_at) with &&
  )
);

-- ------------------------------------------------------------
-- DOCUMENTS
-- ------------------------------------------------------------
create table documents (
  id uuid primary key default uuid_generate_v4(),
  customer_id uuid not null references profiles(id),
  booking_id uuid references bookings(id),
  doc_type text not null check (doc_type in ('licence','govt_id','selfie')),
  storage_path text not null,
  verified boolean not null default false,
  uploaded_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- REVIEWS
-- ------------------------------------------------------------
create table reviews (
  id uuid primary key default uuid_generate_v4(),
  booking_id uuid not null references bookings(id) unique,
  customer_id uuid not null references profiles(id),
  vehicle_id uuid not null references vehicles(id),
  rating int not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- PAYMENTS
-- ------------------------------------------------------------
create table payments (
  id uuid primary key default uuid_generate_v4(),
  booking_id uuid not null references bookings(id),
  razorpay_order_id text,
  razorpay_payment_id text unique,
  amount numeric(10,2) not null,
  currency text not null default 'INR',
  status text not null check (status in ('created','authorized','captured','failed','refunded')),
  raw_payload jsonb,
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- AUDIT LOG
-- ------------------------------------------------------------
create table audit_log (
  id uuid primary key default uuid_generate_v4(),
  actor_id uuid references profiles(id),
  action text not null,
  target_table text,
  target_id uuid,
  detail jsonb,
  created_at timestamptz not null default now()
);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table profiles enable row level security;
alter table vehicles enable row level security;
alter table vehicle_images enable row level security;
alter table vehicle_blocks enable row level security;
alter table bookings enable row level security;
alter table documents enable row level security;
alter table reviews enable row level security;
alter table payments enable row level security;
alter table coupons enable row level security;
alter table audit_log enable row level security;

create function is_admin() returns boolean as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin');
$$ language sql security definer stable;

create function is_owner_of_vehicle(v_id uuid) returns boolean as $$
  select exists (select 1 from vehicles where id = v_id and owner_id = auth.uid());
$$ language sql security definer stable;

-- PROFILES
create policy "profiles_select_own_or_admin" on profiles for select using (id = auth.uid() or is_admin());
create policy "profiles_update_own" on profiles for update using (id = auth.uid());

-- VEHICLES: public sees only verified + available-or-booked (not pending/rejected);
-- owners see and manage their own; admins see and manage all.
create policy "vehicles_select_public_verified" on vehicles
  for select using (verification_status = 'verified' or owner_id = auth.uid() or is_admin());
create policy "vehicles_write_owner_or_admin" on vehicles
  for all using (is_admin() or owner_id = auth.uid())
  with check (is_admin() or owner_id = auth.uid());

create policy "vehicle_images_select_all" on vehicle_images for select using (true);
create policy "vehicle_images_write_owner_or_admin" on vehicle_images
  for all using (is_admin() or is_owner_of_vehicle(vehicle_id));

create policy "vehicle_blocks_select_all" on vehicle_blocks for select using (true);
create policy "vehicle_blocks_write_admin" on vehicle_blocks for all using (is_admin());
  -- customer-created blocks happen only via the service-role backend, never the browser.

-- BOOKINGS: customer sees own; owner sees bookings on their vehicles; admin sees all
create policy "bookings_select_scoped" on bookings
  for select using (customer_id = auth.uid() or owner_id = auth.uid() or is_admin());
create policy "bookings_insert_own" on bookings for insert with check (customer_id = auth.uid());
create policy "bookings_update_owner_or_admin" on bookings
  for update using (owner_id = auth.uid() or is_admin());

-- DOCUMENTS
create policy "documents_select_own_or_admin" on documents for select using (customer_id = auth.uid() or is_admin());
create policy "documents_insert_own" on documents for insert with check (customer_id = auth.uid());

-- REVIEWS: publicly readable; only the booking's customer can write, once, after completion
create policy "reviews_select_all" on reviews for select using (true);
create policy "reviews_insert_own_completed_booking" on reviews
  for insert with check (
    customer_id = auth.uid()
    and exists (select 1 from bookings where id = booking_id and customer_id = auth.uid() and booking_status = 'completed')
  );

-- PAYMENTS / AUDIT LOG: admin-only reads; writes are service-role only
create policy "payments_select_admin" on payments for select using (is_admin());
create policy "audit_log_select_admin" on audit_log for select using (is_admin());

-- COUPONS
create policy "coupons_select_all" on coupons for select using (active = true);
create policy "coupons_write_admin" on coupons for all using (is_admin());

-- ============================================================
-- create_booking() — atomic booking + availability lock, no deposit
-- ============================================================
create or replace function create_booking(
  p_customer_id uuid,
  p_vehicle_id uuid,
  p_owner_id uuid,
  p_booking_code text,
  p_pickup_location text,
  p_return_location text,
  p_pickup_at timestamptz,
  p_return_at timestamptz,
  p_rental_days int,
  p_rental_amount numeric,
  p_discount_amount numeric,
  p_coupon_code text,
  p_coupon_discount numeric,
  p_tax_amount numeric,
  p_total_amount numeric,
  p_driving_licence_no text,
  p_id_proof_type text,
  p_id_proof_number text,
  p_notes text
) returns bookings as $$
declare
  v_booking bookings;
begin
  insert into bookings (
    customer_id, vehicle_id, owner_id, booking_code, pickup_location, return_location,
    pickup_at, return_at, rental_days, rental_amount, discount_amount, coupon_code,
    coupon_discount, tax_amount, total_amount, driving_licence_no, id_proof_type,
    id_proof_number, notes
  ) values (
    p_customer_id, p_vehicle_id, p_owner_id, p_booking_code, p_pickup_location, p_return_location,
    p_pickup_at, p_return_at, p_rental_days, p_rental_amount, p_discount_amount, p_coupon_code,
    p_coupon_discount, p_tax_amount, p_total_amount, p_driving_licence_no, p_id_proof_type,
    p_id_proof_number, p_notes
  ) returning * into v_booking;

  insert into vehicle_blocks (vehicle_id, start_at, end_at, reason, booking_id)
  values (p_vehicle_id, p_pickup_at, p_return_at, 'booking', v_booking.id);

  return v_booking;
end;
$$ language plpgsql security definer;

create or replace function cleanup_stale_bookings(p_older_than_minutes int default 30)
returns int as $$
declare
  v_count int;
begin
  with stale as (
    select id from bookings where booking_status = 'pending' and created_at < now() - (p_older_than_minutes || ' minutes')::interval
  ), released as (
    delete from vehicle_blocks where booking_id in (select id from stale)
  )
  update bookings set booking_status = 'cancelled' where id in (select id from stale);
  get diagnostics v_count = row_count;
  return v_count;
end;
$$ language plpgsql security definer;

-- ============================================================
-- STORAGE: vehicle images (public-read) + private customer documents
-- ============================================================
insert into storage.buckets (id, name, public) values ('vehicle-images', 'vehicle-images', true) on conflict (id) do nothing;
insert into storage.buckets (id, name, public) values ('customer-documents', 'customer-documents', false) on conflict (id) do nothing;

create policy "vehicle_images_public_read" on storage.objects
  for select using (bucket_id = 'vehicle-images');
create policy "vehicle_images_owner_write" on storage.objects
  for insert with check (bucket_id = 'vehicle-images' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "documents_upload_own_folder" on storage.objects
  for insert with check (bucket_id = 'customer-documents' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "documents_read_own_or_admin" on storage.objects
  for select using (bucket_id = 'customer-documents' and ((storage.foldername(name))[1] = auth.uid()::text or is_admin()));

-- ============================================================
-- Seed sample vehicles (remove for production)
-- ============================================================
insert into vehicles (name, brand, model, year, type, seats, fuel, transmission, mileage, ac, luggage, daily_price, status, verification_status, city)
values
  ('Mahindra Thar', 'Mahindra', 'Thar LX', 2023, 'SUV', 4, 'Petrol', 'Manual', '15 km/l', true, '2 large bags', 2500, 'available', 'verified', 'Mumbai'),
  ('Maruti Suzuki Swift', 'Maruti Suzuki', 'Swift VXI', 2022, 'Hatchback', 5, 'Petrol', 'Manual', '21 km/l', true, '2 medium bags', 1300, 'available', 'verified', 'Pune'),
  ('Hyundai Creta', 'Hyundai', 'Creta SX', 2023, 'SUV', 5, 'Diesel', 'Automatic', '18 km/l', true, '3 large bags', 3200, 'available', 'verified', 'Bengaluru');
